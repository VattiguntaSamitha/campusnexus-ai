"""
Groups complaints that likely describe the same underlying issue.

Approach: agglomerative clustering over the similarity matrix produced by
nlp.similarity. Two complaints end up in the same cluster if their
similarity is above a threshold, using a simple union-find (connected
components) approach - easy to explain to a beginner and fully
deterministic given the same inputs.
"""
from typing import List, Dict
import numpy as np

from nlp.similarity import similarity_matrix

SIMILARITY_THRESHOLD = 0.45


class _UnionFind:
    def __init__(self, n: int):
        self.parent = list(range(n))

    def find(self, x: int) -> int:
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, a: int, b: int) -> None:
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.parent[rb] = ra


def cluster_complaints(texts: List[str], threshold: float = SIMILARITY_THRESHOLD) -> List[int]:
    """
    Given a list of complaint texts, return a list of the same length where
    each element is an integer cluster id. Complaints judged similar enough
    (cosine similarity >= threshold) share the same cluster id.
    """
    n = len(texts)
    if n == 0:
        return []
    if n == 1:
        return [0]

    sims = similarity_matrix(texts)
    uf = _UnionFind(n)
    for i in range(n):
        for j in range(i + 1, n):
            if sims[i][j] >= threshold:
                uf.union(i, j)

    # Re-map arbitrary root ids to clean, sequential cluster ids (0, 1, 2, ...).
    root_to_cluster: Dict[int, int] = {}
    cluster_ids = []
    next_id = 0
    for i in range(n):
        root = uf.find(i)
        if root not in root_to_cluster:
            root_to_cluster[root] = next_id
            next_id += 1
        cluster_ids.append(root_to_cluster[root])
    return cluster_ids


def cluster_sizes(cluster_ids: List[int]) -> Dict[int, int]:
    """Return how many complaints fall into each cluster id."""
    sizes: Dict[int, int] = {}
    for cid in cluster_ids:
        sizes[cid] = sizes.get(cid, 0) + 1
    return sizes
