"""
Complaint classification: category, severity, urgency.

Implemented as an explainable, weighted keyword-scoring classifier rather
than a black-box model. This is intentional: the project requires every
prediction to be explainable, and a transparent scorer is easy for a
beginner to read, debug, and extend. It also means the app works
instantly with zero training step.
"""
import re
from typing import Dict, List, Tuple

from backend.config import CATEGORIES


def _contains_keyword(lowered_text: str, keyword: str) -> bool:
    """
    Keyword match with word boundaries for single-word keywords (to prevent
    false positives like the "ac" in "HVAC" keywords list matching inside
    unrelated words such as "back", or "lock" matching inside "Block").
    Multi-word phrases use plain substring matching so plurals/variations
    like "strange noises" still match "strange noise".
    """
    if " " in keyword:
        return keyword in lowered_text
    pattern = r"\b" + re.escape(keyword) + r"\b"
    return re.search(pattern, lowered_text) is not None

# category -> keywords that signal it
_CATEGORY_KEYWORDS: Dict[str, List[str]] = {
    "HVAC": ["ac", "air condition", "hot", "cold", "temperature", "chiller",
              "hvac", "noisy", "noise", "cooling", "heater", "fan"],
    "WATER": ["water", "leak", "leaking", "tap", "pipe", "flood", "flow",
              "faucet", "drip", "valve", "damp", "moisture"],
    "ELECTRICITY": ["electric", "electricity", "power", "socket", "wire",
                     "wiring", "voltage", "spark", "short circuit", "breaker",
                     "transformer", "outage", "blackout"],
    "NETWORK": ["wifi", "wi-fi", "internet", "network", "router", "connection",
                 "lan", "connectivity"],
    "EQUIPMENT": ["projector", "printer", "computer", "elevator", "lift",
                   "machine", "equipment", "broken", "malfunction"],
    "SANITATION": ["toilet", "washroom", "restroom", "dirty", "garbage",
                    "trash", "smell", "unclean", "hygiene", "sanitation"],
    "SECURITY": ["security", "theft", "stolen", "cctv", "camera", "lock",
                  "unsafe", "intruder", "trespass", "guard"],
}

_SEVERITY_KEYWORDS = {
    "HIGH": ["fire", "spark", "flood", "smoke", "danger", "dangerous",
              "severe", "burst", "shock", "collapse", "urgent", "emergency",
              "not working at all", "completely broken", "strange noise"],
    "MEDIUM": ["not cooling", "not working", "broken", "leak", "slow",
                "intermittent", "sometimes", "partially"],
    "LOW": ["minor", "small", "slight", "flicker", "cosmetic"],
}

_URGENCY_KEYWORDS = {
    "HIGH": ["immediately", "urgent", "asap", "right now", "emergency",
              "danger", "unsafe", "fire", "spark", "flood"],
    "MEDIUM": ["today", "soon", "please fix", "as soon as possible"],
    "LOW": ["whenever", "no rush", "eventually"],
}


def classify_category(text: str) -> str:
    """Score each category by keyword hits and return the highest scorer."""
    lowered = text.lower()
    scores = {cat: 0 for cat in CATEGORIES}
    for cat, keywords in _CATEGORY_KEYWORDS.items():
        for kw in keywords:
            if _contains_keyword(lowered, kw):
                scores[cat] += 1
    best_cat = max(scores, key=scores.get)
    return best_cat if scores[best_cat] > 0 else "OTHER"


def _score_level(text: str, keyword_map: Dict[str, List[str]], default: str) -> Tuple[str, int]:
    lowered = text.lower()
    best_level, best_score = default, 0
    for level, keywords in keyword_map.items():
        score = sum(1 for kw in keywords if _contains_keyword(lowered, kw))
        if score > best_score:
            best_level, best_score = level, score
    return best_level, best_score


def classify_severity(text: str) -> str:
    level, score = _score_level(text, _SEVERITY_KEYWORDS, default="MEDIUM")
    return level if score > 0 else "MEDIUM"


def classify_urgency(text: str) -> str:
    level, score = _score_level(text, _URGENCY_KEYWORDS, default="MEDIUM")
    return level if score > 0 else "MEDIUM"


def describe_problem(category: str, text: str) -> str:
    """Generate a short human-readable problem description."""
    lowered = text.lower()
    templates = {
        "HVAC": "possible AC/HVAC failure",
        "WATER": "possible water leak or plumbing issue",
        "ELECTRICITY": "possible electrical fault",
        "NETWORK": "network/connectivity issue",
        "EQUIPMENT": "equipment malfunction",
        "SANITATION": "sanitation/cleanliness issue",
        "SECURITY": "security concern",
        "OTHER": "general facility issue",
    }
    base = templates.get(category, "general facility issue")
    if "noise" in lowered or "noisy" in lowered:
        base += " (unusual noise reported)"
    return base
