"""
Semantic similarity between complaints.

Primary path: TF-IDF + cosine similarity (scikit-learn). This has ZERO
external downloads and always works, which is why it is the default.

Optional upgrade: if `sentence-transformers` is installed AND the model can
be downloaded, embeddings from it are used instead for higher-quality
semantic matching (e.g. matching "AC not cooling" with "room is very hot"
even without shared keywords). If loading fails for any reason (no
internet, package missing, etc.) the code automatically falls back to
TF-IDF - satisfying the "must have a fallback" requirement.
"""
from typing import List
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

_sentence_model = None
_sentence_model_checked = False


def _try_load_sentence_transformer():
    global _sentence_model, _sentence_model_checked
    if _sentence_model_checked:
        return _sentence_model
    _sentence_model_checked = True
    try:
        from sentence_transformers import SentenceTransformer
        _sentence_model = SentenceTransformer("all-MiniLM-L6-v2")
    except Exception:
        # Covers: package not installed, no internet to download weights,
        # or any other runtime issue. Fall back silently and safely.
        _sentence_model = None
    return _sentence_model


def embed_texts(texts: List[str]) -> np.ndarray:
    """
    Return a 2D embedding matrix for the given texts.

    Uses sentence-transformers if available, otherwise TF-IDF vectors.
    """
    model = _try_load_sentence_transformer()
    if model is not None:
        return np.array(model.encode(texts))

    vectorizer = TfidfVectorizer(stop_words="english", max_features=2000)
    matrix = vectorizer.fit_transform(texts)
    return matrix.toarray()


def similarity_matrix(texts: List[str]) -> np.ndarray:
    """Pairwise cosine similarity matrix for a list of texts."""
    if len(texts) == 0:
        return np.zeros((0, 0))
    embeddings = embed_texts(texts)
    return cosine_similarity(embeddings)


def most_similar(query: str, corpus: List[str], top_k: int = 5, threshold: float = 0.35):
    """
    Return up to `top_k` items from `corpus` most similar to `query`,
    as a list of (index, score) tuples, filtered by `threshold`.
    """
    if not corpus:
        return []
    texts = [query] + corpus
    sims = similarity_matrix(texts)[0][1:]  # similarity of query vs each corpus item
    ranked = sorted(enumerate(sims), key=lambda x: x[1], reverse=True)
    return [(idx, float(score)) for idx, score in ranked[:top_k] if score >= threshold]


def using_semantic_model() -> bool:
    """Whether a real sentence-transformers model is active (for status/debug)."""
    return _try_load_sentence_transformer() is not None
