"""
Top-level NLP pipeline: ties together preprocessing, entity extraction,
classification and similarity into a single `analyze_complaint()` call.
"""
from typing import List, Dict, Any

from nlp.preprocessing import clean_text
from nlp.entity_extractor import extract_entities
from nlp.classifier import classify_category, classify_severity, classify_urgency, describe_problem
from nlp.similarity import most_similar


def analyze_complaint(text: str) -> Dict[str, Any]:
    """
    Run the full NLP pipeline on a single complaint and return a structured
    dictionary matching the project's required output shape.
    """
    cleaned = clean_text(text)
    entities = extract_entities(cleaned)
    category = classify_category(cleaned)
    severity = classify_severity(cleaned)
    urgency = classify_urgency(cleaned)
    problem = describe_problem(category, cleaned)

    return {
        "building": entities["building"],
        "room": entities["room"],
        "equipment": entities["equipment"],
        "category": category,
        "problem": problem,
        "severity": severity,
        "urgency": urgency,
    }


def find_similar_complaints(text: str, historical_texts: List[str], top_k: int = 5) -> List[Dict[str, Any]]:
    """
    Compare a new complaint against historical complaint texts and return the
    most semantically similar ones with their similarity score.
    """
    matches = most_similar(text, historical_texts, top_k=top_k)
    return [{"index": idx, "similarity": round(score, 3)} for idx, score in matches]
