"""
Text cleaning, tokenization and normalization.

This module has NO hard dependency on spaCy. If spaCy + a language model are
installed and downloadable, it will use them for better tokenization;
otherwise it falls back to a simple, dependency-free regex tokenizer.
This satisfies the requirement that the app must work even if a model
cannot be downloaded.
"""
import re
from typing import List

_STOPWORDS = {
    "the", "a", "an", "is", "are", "was", "were", "in", "on", "at", "of",
    "to", "and", "or", "for", "it", "this", "that", "has", "have", "had",
    "be", "been", "being", "with", "as", "by", "from", "there", "we",
    "i", "my", "our", "please", "very", "so",
}

_TOKEN_RE = re.compile(r"[A-Za-z0-9°]+")

_nlp_spacy = None
_spacy_checked = False


def _try_load_spacy():
    """Attempt to load a spaCy model once. Returns None if unavailable."""
    global _nlp_spacy, _spacy_checked
    if _spacy_checked:
        return _nlp_spacy
    _spacy_checked = True
    try:
        import spacy
        try:
            _nlp_spacy = spacy.load("en_core_web_sm")
        except OSError:
            # Model not downloaded - fall back gracefully.
            _nlp_spacy = None
    except ImportError:
        _nlp_spacy = None
    return _nlp_spacy


def clean_text(text: str) -> str:
    """Lowercase, strip extra whitespace, remove stray punctuation noise."""
    text = text.strip()
    text = re.sub(r"\s+", " ", text)
    return text


def tokenize(text: str) -> List[str]:
    """
    Tokenize text into lowercase word tokens.

    Uses spaCy if available for slightly better tokenization (handles
    contractions, punctuation edge cases); otherwise uses a regex tokenizer
    which works identically well for this project's purposes.
    """
    cleaned = clean_text(text)
    nlp = _try_load_spacy()
    if nlp is not None:
        doc = nlp(cleaned)
        return [tok.text.lower() for tok in doc if not tok.is_space]
    return [tok.lower() for tok in _TOKEN_RE.findall(cleaned)]


def normalize_tokens(tokens: List[str], remove_stopwords: bool = True) -> List[str]:
    """Lowercase + optionally remove stopwords. Keeps numbers/room codes intact."""
    tokens = [t.lower() for t in tokens]
    if remove_stopwords:
        tokens = [t for t in tokens if t not in _STOPWORDS]
    return tokens


def preprocess(text: str) -> List[str]:
    """Full pipeline: clean -> tokenize -> normalize. Returns list of tokens."""
    tokens = tokenize(text)
    return normalize_tokens(tokens)


def spacy_available() -> bool:
    """Whether a real spaCy model is loaded (used for status/debug endpoints)."""
    return _try_load_spacy() is not None
