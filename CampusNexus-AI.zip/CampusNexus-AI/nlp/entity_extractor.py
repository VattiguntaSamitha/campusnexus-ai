"""
Rule + dictionary based Named Entity Extraction for campus complaints.

Extracts: building, room number, equipment. This is deterministic (not a
black box), which keeps the whole pipeline explainable - a key requirement
of this project's risk engine.
"""
import re
from typing import Optional, Dict

from backend.config import BUILDINGS

# Map of common aliases -> canonical building name.
_BUILDING_ALIASES = {
    "block a": "Block A", "block-a": "Block A", "blocka": "Block A",
    "block b": "Block B", "block-b": "Block B", "blockb": "Block B",
    "block c": "Block C", "block-c": "Block C", "blockc": "Block C",
    "library": "Library",
    "lab block": "Laboratory Block", "laboratory block": "Laboratory Block",
    "laboratory": "Laboratory Block", "lab building": "Laboratory Block",
    "admin block": "Administration Block", "administration": "Administration Block",
    "administration block": "Administration Block", "admin building": "Administration Block",
}

_ROOM_RE = re.compile(r"\broom\s*(?:no\.?|number)?\s*[:#-]?\s*(\d{2,4}[a-zA-Z]?)\b", re.IGNORECASE)
_BARE_ROOM_RE = re.compile(r"\b(\d{3,4})\b")  # e.g. "304" standing alone

_EQUIPMENT_KEYWORDS = {
    "ac": "AC", "a/c": "AC", "air conditioner": "AC", "air conditioning": "AC",
    "aircon": "AC", "chiller": "Chiller", "hvac": "HVAC Unit",
    "fan": "Fan", "ceiling fan": "Fan",
    "tap": "Water Tap", "faucet": "Water Tap", "pipe": "Water Pipe",
    "pipeline": "Water Pipe", "valve": "Water Valve", "geyser": "Water Heater",
    "water heater": "Water Heater", "toilet": "Sanitation Fixture",
    "wire": "Electrical Wiring", "wiring": "Electrical Wiring",
    "socket": "Power Socket", "plug point": "Power Socket",
    "panel": "Electrical Panel", "breaker": "Circuit Breaker",
    "transformer": "Transformer", "generator": "Generator",
    "wifi": "Wi-Fi Router", "wi-fi": "Wi-Fi Router", "router": "Wi-Fi Router",
    "internet": "Network", "network": "Network",
    "projector": "Projector", "printer": "Printer", "computer": "Computer",
    "cctv": "CCTV Camera", "camera": "CCTV Camera", "lock": "Door Lock",
    "door": "Door", "window": "Window", "light": "Light Fixture",
    "bulb": "Light Fixture", "tube light": "Light Fixture",
    "elevator": "Elevator", "lift": "Elevator", "pump": "Water Pump",
}


def extract_building(text: str) -> Optional[str]:
    lowered = text.lower()
    for alias, canonical in _BUILDING_ALIASES.items():
        if alias in lowered:
            return canonical
    # Direct match against canonical names too.
    for b in BUILDINGS:
        if b.lower() in lowered:
            return b
    return None


def extract_room(text: str) -> Optional[str]:
    match = _ROOM_RE.search(text)
    if match:
        return match.group(1)
    # Fallback: a bare 3-4 digit number that looks like a room code.
    match = _BARE_ROOM_RE.search(text)
    if match:
        return match.group(1)
    return None


def extract_equipment(text: str) -> Optional[str]:
    lowered = text.lower()
    # Sort keys by length (longest first) so "air conditioner" wins over "ac".
    # Word-boundary matching prevents false hits like "lock" inside "Block".
    for kw in sorted(_EQUIPMENT_KEYWORDS.keys(), key=len, reverse=True):
        pattern = r"\b" + re.escape(kw) + r"\b"
        if re.search(pattern, lowered):
            return _EQUIPMENT_KEYWORDS[kw]
    return None


def extract_entities(text: str) -> Dict[str, Optional[str]]:
    """Run all extractors and return a single dict of entities."""
    return {
        "building": extract_building(text),
        "room": extract_room(text),
        "equipment": extract_equipment(text),
    }
