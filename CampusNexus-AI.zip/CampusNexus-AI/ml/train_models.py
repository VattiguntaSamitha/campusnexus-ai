"""
Trains the anomaly detection and electricity forecasting models on the
synthetic telemetry data and saves them to /models using joblib.

Run via: python scripts/train.py
"""
import os
import logging
import joblib
import pandas as pd

from backend.config import DATA_DIR, MODELS_DIR
from ml.anomaly_detection import train_anomaly_model
from ml.electricity_prediction import train_electricity_model

logger = logging.getLogger("campusnexus.train")
logging.basicConfig(level=logging.INFO)


def train_and_save_all() -> None:
    telemetry_path = os.path.join(DATA_DIR, "telemetry.csv")
    if not os.path.exists(telemetry_path):
        raise FileNotFoundError(
            f"telemetry.csv not found at {telemetry_path}. "
            "Run `python scripts/generate_data.py` first."
        )

    df = pd.read_csv(telemetry_path, parse_dates=["timestamp"])
    os.makedirs(MODELS_DIR, exist_ok=True)

    logger.info("Training Isolation Forest anomaly detection model...")
    anomaly_model = train_anomaly_model(df)
    joblib.dump(anomaly_model, os.path.join(MODELS_DIR, "anomaly_model.joblib"))

    logger.info("Training electricity load regression model...")
    electricity_model = train_electricity_model(df)
    joblib.dump(electricity_model, os.path.join(MODELS_DIR, "electricity_model.joblib"))

    logger.info("Models saved to %s", MODELS_DIR)


if __name__ == "__main__":
    train_and_save_all()
