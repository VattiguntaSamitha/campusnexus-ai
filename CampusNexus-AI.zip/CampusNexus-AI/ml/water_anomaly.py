"""
Water leakage / abnormal usage detection.

Compares current water flow against a rolling historical baseline for the
same building and time-of-day, factoring in occupancy (more people should
mean somewhat more usage - a spike WITHOUT matching occupancy is more
suspicious of a leak).
"""
from typing import Dict, List


def water_anomaly_risk(
    current_flow_lpm: float,
    baseline_flow_lpm: float,
    occupancy: int,
    baseline_occupancy: int,
    hour_of_day: int,
) -> Dict:
    score = 0
    evidence: List[str] = []

    if baseline_flow_lpm <= 0:
        baseline_flow_lpm = 1.0  # avoid divide-by-zero

    pct_above = ((current_flow_lpm - baseline_flow_lpm) / baseline_flow_lpm) * 100

    if pct_above > 60:
        score += 45
        evidence.append(f"water flow {pct_above:.0f}% above historical baseline")
    elif pct_above > 30:
        score += 25
        evidence.append(f"water flow {pct_above:.0f}% above historical baseline")
    elif pct_above > 15:
        score += 10
        evidence.append(f"water flow {pct_above:.0f}% above historical baseline")

    occupancy_ratio = occupancy / max(baseline_occupancy, 1)
    flow_ratio = current_flow_lpm / baseline_flow_lpm

    # A flow spike that is NOT explained by more people in the building is
    # a strong leak indicator.
    if flow_ratio > occupancy_ratio + 0.4:
        score += 30
        evidence.append("flow increase is not explained by occupancy - possible leak")

    is_off_hours = hour_of_day < 6 or hour_of_day > 22
    if is_off_hours and current_flow_lpm > baseline_flow_lpm * 1.2:
        score += 25
        evidence.append("elevated water flow detected during off-hours")

    return {"score": min(score, 100), "evidence": evidence}
