"""
Lightweight electricity load forecasting + overload risk scoring.

Uses a small linear regression trained on synthetic telemetry (occupancy,
temperature, hvac_on, wifi_users -> electricity_kw) as a lightweight,
fast, explainable time-series-adjacent approach, as requested by the
project spec ("lightweight approach" for forecasting).
"""
from typing import Dict
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression

FEATURES = ["occupancy", "temperature_c", "wifi_users", "hvac_on_int"]


def _prep(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["hvac_on_int"] = df["hvac_on"].astype(int)
    return df


def train_electricity_model(telemetry_df: pd.DataFrame) -> LinearRegression:
    df = _prep(telemetry_df)
    X = df[FEATURES].values
    y = df["electricity_kw"].values
    model = LinearRegression()
    model.fit(X, y)
    return model


def predict_electricity(model: LinearRegression, occupancy: int, temperature_c: float,
                         wifi_users: int, hvac_on: bool) -> float:
    X = np.array([[occupancy, temperature_c, wifi_users, int(hvac_on)]])
    prediction = model.predict(X)[0]
    return float(max(prediction, 0.0))


def electricity_overload_evidence(current_kw: float, baseline_kw: float, occupancy_pct: float,
                                   temperature_c: float) -> Dict:
    """Build explainable evidence for an electricity overload risk score."""
    pct_above_baseline = 0.0
    if baseline_kw > 0:
        pct_above_baseline = ((current_kw - baseline_kw) / baseline_kw) * 100

    evidence = []
    score = 0

    if pct_above_baseline > 25:
        evidence.append(f"electricity {pct_above_baseline:.0f}% above normal baseline")
        score += 40
    elif pct_above_baseline > 10:
        evidence.append(f"electricity {pct_above_baseline:.0f}% above normal baseline")
        score += 20

    if occupancy_pct > 80:
        evidence.append(f"occupancy {occupancy_pct:.0f}% of capacity")
        score += 20
    elif occupancy_pct > 60:
        evidence.append(f"occupancy {occupancy_pct:.0f}% of capacity")
        score += 10

    if temperature_c > 32:
        evidence.append(f"temperature {temperature_c:.0f}°C driving heavy HVAC use")
        score += 20
    elif temperature_c > 28:
        evidence.append(f"temperature {temperature_c:.0f}°C increasing HVAC load")
        score += 10

    if current_kw > baseline_kw * 1.3:
        evidence.append("sustained high draw suggests possible overload condition")
        score += 20

    return {"score": min(score, 100), "evidence": evidence}
