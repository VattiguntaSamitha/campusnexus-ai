"""
General-purpose anomaly detection over campus telemetry using Isolation
Forest (scikit-learn). Used to flag buildings whose current readings are
statistically unusual compared to recent history.
"""
from typing import List
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest


FEATURE_COLUMNS = ["temperature_c", "electricity_kw", "water_flow_lpm", "occupancy", "wifi_users"]


def train_anomaly_model(telemetry_df: pd.DataFrame) -> IsolationForest:
    """
    Fit an Isolation Forest on historical telemetry so it learns what
    "normal" campus conditions look like.
    """
    X = telemetry_df[FEATURE_COLUMNS].values
    model = IsolationForest(
        n_estimators=150,
        contamination=0.05,  # assume ~5% of historical readings were anomalous
        random_state=42,
    )
    model.fit(X)
    return model


def score_anomaly(model: IsolationForest, row: dict) -> float:
    """
    Return an anomaly score in [0, 100] for a single telemetry reading,
    where higher = more abnormal. Uses the model's decision_function,
    which is negative for outliers and positive for inliers, then rescales.
    """
    X = np.array([[row[c] for c in FEATURE_COLUMNS]])
    raw_score = model.decision_function(X)[0]  # roughly in [-0.5, 0.5]
    # Flip sign (so higher = more abnormal) and rescale to 0-100.
    normalized = (0.5 - raw_score) / 1.0
    return float(np.clip(normalized * 100, 0, 100))


def is_anomalous(model: IsolationForest, row: dict) -> bool:
    X = np.array([[row[c] for c in FEATURE_COLUMNS]])
    prediction = model.predict(X)[0]  # -1 = anomaly, 1 = normal
    return prediction == -1
