"""
Shared helpers for converting a numeric 0-100 score into a risk level label,
and for generating a recommended action string. Used by both the ML
modules and backend/services/risk_engine.py (which orchestrates DB access).
"""
from typing import List


def score_to_level(score: float) -> str:
    if score >= 65:
        return "HIGH"
    if score >= 35:
        return "MEDIUM"
    return "LOW"


def recommended_action(risk_type: str, building: str, risk_level: str) -> str:
    actions = {
        "HVAC": {
            "HIGH": f"Schedule urgent preventive maintenance for {building} HVAC units.",
            "MEDIUM": f"Inspect {building} HVAC units within the next few days.",
            "LOW": f"No immediate action needed for {building} HVAC; continue routine monitoring.",
        },
        "WATER": {
            "HIGH": f"Dispatch a plumber to inspect {building} immediately for possible leaks.",
            "MEDIUM": f"Check {building} plumbing and water lines this week.",
            "LOW": f"No immediate action needed for {building} water systems.",
        },
        "ELECTRICITY": {
            "HIGH": f"Reduce non-critical electrical load in {building} and inspect the electrical panel.",
            "MEDIUM": f"Monitor {building} electricity usage and inspect panels if trend continues.",
            "LOW": f"No immediate action needed for {building} electrical systems.",
        },
    }
    return actions.get(risk_type, {}).get(risk_level, "Monitor the situation.")


def combine_evidence(*evidence_lists: List[str]) -> List[str]:
    combined = []
    for lst in evidence_lists:
        combined.extend(lst)
    return combined
