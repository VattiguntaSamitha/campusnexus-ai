"""
HVAC / equipment failure risk scoring.

Combines complaint frequency, equipment age, health score, previous
failures, and abnormal temperature into an explainable weighted score
(a Random-Forest-style ensemble would add little value here since the
inputs are already few and well understood — a transparent weighted rule
model is more appropriate and fully auditable, per the project's
explainability requirement).
"""
from datetime import datetime
from typing import Dict, List


def equipment_failure_risk(
    complaint_count_recent: int,
    equipment_age_years: float,
    health_score: float,
    previous_failures: int,
    current_temperature_c: float,
    baseline_temperature_c: float,
) -> Dict:
    """
    Returns {"score": 0-100, "evidence": [...]}.
    Higher score = higher likelihood of imminent equipment failure.
    """
    score = 0
    evidence: List[str] = []

    if complaint_count_recent >= 3:
        score += 30
        evidence.append(f"{complaint_count_recent} related complaints in recent history")
    elif complaint_count_recent >= 1:
        score += 15
        evidence.append(f"{complaint_count_recent} related complaint(s) reported recently")

    if equipment_age_years >= 10:
        score += 20
        evidence.append(f"equipment is {equipment_age_years:.0f} years old (aging unit)")
    elif equipment_age_years >= 6:
        score += 10
        evidence.append(f"equipment is {equipment_age_years:.0f} years old")

    if health_score < 50:
        score += 25
        evidence.append(f"equipment health score is low ({health_score:.0f}/100)")
    elif health_score < 70:
        score += 12
        evidence.append(f"equipment health score is moderate ({health_score:.0f}/100)")

    if previous_failures >= 2:
        score += 15
        evidence.append(f"{previous_failures} previous failure(s) on record")
    elif previous_failures == 1:
        score += 8
        evidence.append("1 previous failure on record")

    temp_delta = current_temperature_c - baseline_temperature_c
    if temp_delta >= 4:
        score += 10
        evidence.append(f"room temperature {temp_delta:.1f}°C above baseline")

    return {"score": min(score, 100), "evidence": evidence}


def equipment_age_years(install_year: int) -> float:
    return max(datetime.utcnow().year - install_year, 0)
