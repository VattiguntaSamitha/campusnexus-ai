"""
Integration tests for the FastAPI application, using a temporary SQLite
database so these tests never touch your real campusnexus.db.
"""
import os
import sys
import tempfile

import pytest

# Point the app at a throwaway database BEFORE importing backend modules,
# so SQLAlchemy's engine is created against the test database.
_TMP_DB_FD, _TMP_DB_PATH = tempfile.mkstemp(suffix=".db")
os.environ["DATABASE_URL"] = f"sqlite:///{_TMP_DB_PATH}"

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fastapi.testclient import TestClient  # noqa: E402
from backend.main import app  # noqa: E402
from backend.database import init_db, SessionLocal  # noqa: E402
from backend import models  # noqa: E402


@pytest.fixture(scope="module")
def client():
    init_db()
    db = SessionLocal()
    # Minimal seed data so dashboard/predictions endpoints have something
    # to compute over, without needing the full synthetic data generator.
    if db.query(models.Building).count() == 0:
        b = models.Building(name="Block B", latitude=28.61, longitude=77.20, total_rooms=10, year_built=2005)
        db.add(b)
        db.commit()
        db.refresh(b)

        db.add(models.Equipment(building_id=b.id, room_number="304", equipment_type="AC",
                                  install_year=2012, health_score=45.0, previous_failures=2))
        db.commit()

        from datetime import datetime, timedelta
        now = datetime.utcnow()
        for i in range(5):
            db.add(models.Telemetry(
                building_id=b.id, timestamp=now - timedelta(hours=i),
                temperature_c=30.0, electricity_kw=20.0, water_flow_lpm=25.0,
                occupancy=80, wifi_users=60, hvac_on=True,
            ))
        db.commit()
    db.close()

    with TestClient(app) as test_client:
        yield test_client

    os.close(_TMP_DB_FD)
    os.remove(_TMP_DB_PATH)


def test_health_check(client):
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_dashboard_returns_buildings(client):
    response = client.get("/api/dashboard")
    assert response.status_code == 200
    data = response.json()
    assert data["total_buildings"] >= 1
    assert "buildings" in data


def test_buildings_endpoint(client):
    response = client.get("/api/buildings")
    assert response.status_code == 200
    names = [b["name"] for b in response.json()]
    assert "Block B" in names


def test_analyze_complaint_endpoint(client):
    response = client.post("/api/analyze-complaint", json={
        "text": "The AC in Block B room 304 is making strange noise and the room is very hot."
    })
    assert response.status_code == 200
    data = response.json()
    assert data["building"] == "Block B"
    assert data["room"] == "304"
    assert data["category"] == "HVAC"


def test_submit_complaint_persists(client):
    response = client.post("/api/complaints", json={
        "text": "There is a water leak near the washroom in Block B.",
        "reporter_role": "student",
    })
    assert response.status_code == 200
    data = response.json()
    assert data["category"] == "WATER"
    assert data["id"] is not None


def test_risks_endpoint(client):
    response = client.get("/api/risks")
    assert response.status_code == 200
    risks = response.json()
    assert len(risks) > 0
    for r in risks:
        assert "risk_score" in r and "evidence" in r


def test_simulate_endpoint(client):
    response = client.post("/api/simulate", json={
        "building": "Block B",
        "ac_temperature_c": 24,
        "non_critical_equipment_on": False,
    })
    assert response.status_code == 200
    data = response.json()
    assert "before" in data and "after" in data and "difference" in data


def test_simulate_unknown_building_returns_404(client):
    response = client.post("/api/simulate", json={"building": "Nonexistent Hall"})
    assert response.status_code == 404


def test_assistant_endpoint(client):
    response = client.post("/api/assistant", json={"question": "Which building has the highest risk?"})
    assert response.status_code == 200
    data = response.json()
    assert data["source"] in ("local", "llm")
    assert len(data["answer"]) > 0
