"""
Tests for the explainable risk engine (ml/ scoring functions).
"""
from ml.equipment_failure import equipment_failure_risk, equipment_age_years
from ml.water_anomaly import water_anomaly_risk
from ml.electricity_prediction import electricity_overload_evidence
from ml.risk_engine import score_to_level, recommended_action


def test_score_to_level_thresholds():
    assert score_to_level(10) == "LOW"
    assert score_to_level(50) == "MEDIUM"
    assert score_to_level(80) == "HIGH"


def test_equipment_failure_risk_high_for_old_unhealthy_unit():
    result = equipment_failure_risk(
        complaint_count_recent=4,
        equipment_age_years=12,
        health_score=40,
        previous_failures=2,
        current_temperature_c=33,
        baseline_temperature_c=26,
    )
    assert result["score"] >= 65
    assert len(result["evidence"]) > 0


def test_equipment_failure_risk_low_for_healthy_new_unit():
    result = equipment_failure_risk(
        complaint_count_recent=0,
        equipment_age_years=1,
        health_score=95,
        previous_failures=0,
        current_temperature_c=25,
        baseline_temperature_c=25,
    )
    assert result["score"] < 35


def test_water_anomaly_detects_unexplained_spike():
    result = water_anomaly_risk(
        current_flow_lpm=80,
        baseline_flow_lpm=25,
        occupancy=5,
        baseline_occupancy=5,
        hour_of_day=2,
    )
    assert result["score"] >= 65
    assert any("leak" in e or "off-hours" in e or "baseline" in e for e in result["evidence"])


def test_water_anomaly_low_for_normal_conditions():
    result = water_anomaly_risk(
        current_flow_lpm=26,
        baseline_flow_lpm=25,
        occupancy=100,
        baseline_occupancy=100,
        hour_of_day=14,
    )
    assert result["score"] < 35


def test_electricity_overload_evidence_flags_high_draw():
    result = electricity_overload_evidence(
        current_kw=45, baseline_kw=25, occupancy_pct=85, temperature_c=34,
    )
    assert result["score"] >= 65


def test_equipment_age_years_never_negative():
    assert equipment_age_years(2999) == 0


def test_recommended_action_varies_by_level():
    high = recommended_action("HVAC", "Block B", "HIGH")
    low = recommended_action("HVAC", "Block B", "LOW")
    assert "Block B" in high and "Block B" in low
    assert high != low
