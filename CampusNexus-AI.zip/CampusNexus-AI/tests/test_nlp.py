"""
Tests for the NLP pipeline: entity extraction, classification, similarity,
and clustering.
"""
from nlp.pipeline import analyze_complaint
from nlp.entity_extractor import extract_building, extract_room, extract_equipment
from nlp.classifier import classify_category, classify_severity
from nlp.similarity import most_similar
from nlp.clustering import cluster_complaints


def test_extract_building():
    assert extract_building("The AC in Block B room 304 is broken") == "Block B"
    assert extract_building("Issue in the Library") == "Library"


def test_extract_room():
    assert extract_room("The AC in Block B room 304 is broken") == "304"


def test_extract_equipment_ignores_block_substring():
    # Regression test: "Block" contains "lock" as a substring, which must
    # NOT be misidentified as "Door Lock" equipment.
    entities_equipment = extract_equipment("The AC in Block B room 304 is broken")
    assert entities_equipment == "AC"


def test_classify_category_hvac():
    text = "The AC in Block B room 304 is making strange noise and the room is very hot."
    assert classify_category(text) == "HVAC"


def test_classify_category_water():
    text = "There is a water leak near the washroom in Block C."
    assert classify_category(text) == "WATER"


def test_classify_severity_high_for_danger_words():
    assert classify_severity("There is a fire hazard, smoke everywhere, emergency!") == "HIGH"


def test_full_pipeline_matches_demo_scenario():
    text = "The AC in Block B room 304 has been making strange noises and the room is very hot."
    result = analyze_complaint(text)
    assert result["building"] == "Block B"
    assert result["room"] == "304"
    assert result["category"] == "HVAC"
    assert result["severity"] == "HIGH"


def test_similarity_finds_related_complaints():
    corpus = [
        "AC is not cooling in room 304.",
        "Room 304 is very hot.",
        "The washroom in Block A is dirty.",
    ]
    matches = most_similar("The air conditioner in 304 isn't working.", corpus, top_k=3, threshold=0.1)
    assert len(matches) > 0
    # The top match should be one of the two HVAC-related complaints (index 0 or 1),
    # not the unrelated sanitation complaint (index 2).
    top_index = matches[0][0]
    assert top_index in (0, 1)


def test_clustering_groups_similar_complaints():
    # NOTE: with the default TF-IDF fallback (no sentence-transformers model
    # installed), similarity relies on shared keywords rather than deep
    # semantic meaning. These two texts share "AC"/"cooling"-style wording
    # and should cluster together; the unrelated sanitation complaint
    # should not join them. (Installing sentence-transformers improves
    # matches like "AC not cooling" <-> "room is hot" with no shared words.)
    texts = [
        "AC is not cooling in room 304.",
        "The AC in room 304 is not cooling properly.",
        "Washroom in Block A is dirty and smells bad.",
    ]
    cluster_ids = cluster_complaints(texts, threshold=0.3)
    assert cluster_ids[0] == cluster_ids[1]
    assert cluster_ids[2] != cluster_ids[0]
