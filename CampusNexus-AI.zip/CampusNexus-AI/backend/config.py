"""
Central configuration for CampusNexus AI.

All values can be overridden with environment variables (see .env.example).
Nothing here requires a paid API key - the app works fully offline.
"""
import os
from dotenv import load_dotenv

# Load variables from a .env file if one exists in the project root.
load_dotenv()

# --- Database ---
DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./campusnexus.db")

# --- Optional LLM ---
# If LLM_API_KEY is empty, the AI Assistant automatically uses the local,
# deterministic, database-backed assistant instead of calling an external API.
LLM_API_KEY: str = os.getenv("LLM_API_KEY", "").strip()
LLM_PROVIDER: str = os.getenv("LLM_PROVIDER", "openai").strip().lower()

# --- Paths ---
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
MODELS_DIR = os.path.join(BASE_DIR, "models")

# --- Campus constants (used by data generation + NLP + risk engine) ---
BUILDINGS = [
    "Block A",
    "Block B",
    "Block C",
    "Library",
    "Laboratory Block",
    "Administration Block",
]

CATEGORIES = [
    "HVAC",
    "WATER",
    "ELECTRICITY",
    "NETWORK",
    "EQUIPMENT",
    "SANITATION",
    "SECURITY",
    "OTHER",
]

SEVERITY_LEVELS = ["LOW", "MEDIUM", "HIGH"]
URGENCY_LEVELS = ["LOW", "MEDIUM", "HIGH"]

# --- Logging ---
LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")
