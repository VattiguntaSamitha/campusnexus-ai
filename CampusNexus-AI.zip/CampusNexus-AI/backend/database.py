"""
Database engine/session setup for CampusNexus AI.

Uses SQLite by default so the project runs with zero external services.
"""
import logging
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

from backend.config import DATABASE_URL

logger = logging.getLogger("campusnexus.database")

# `check_same_thread=False` is required for SQLite when used with FastAPI,
# because FastAPI can access the DB from different worker threads.
connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}

engine = create_engine(DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    """FastAPI dependency that yields a database session and always closes it."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db() -> None:
    """Create all tables if they do not already exist."""
    # Importing models here (not at module load time) avoids circular imports
    # between database.py and models.py.
    from backend import models  # noqa: F401

    Base.metadata.create_all(bind=engine)
    logger.info("Database tables ensured at %s", DATABASE_URL)
