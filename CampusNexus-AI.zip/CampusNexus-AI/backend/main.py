"""
CampusNexus AI - FastAPI application entrypoint.

Run with:
    uvicorn backend.main:app --reload

On startup this:
  1. Creates database tables if they don't exist.
  2. Seeds the database with synthetic demo data if it's empty.
"""
import logging
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from backend.database import init_db
from backend.utils.seed_database import seed_if_empty
from backend.api import complaints, dashboard, predictions, simulation, assistant

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(name)s] %(levelname)s: %(message)s")
logger = logging.getLogger("campusnexus.main")

app = FastAPI(
    title="CampusNexus AI",
    description="NLP-Powered Predictive Campus Digital Twin",
    version="1.0.0",
)

# Allow the Vite dev server (and any local frontend) to call the API.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def on_startup():
    logger.info("Starting CampusNexus AI backend...")
    init_db()
    try:
        seed_if_empty()
    except Exception:
        logger.exception(
            "Automatic seeding failed. Run `python scripts/seed.py` manually, then restart the server."
        )


@app.get("/api/health", tags=["health"])
def health_check():
    """Simple liveness check used by the frontend and for smoke-testing the API."""
    return {"status": "ok", "service": "CampusNexus AI"}


# Register all feature routers under the /api prefix.
app.include_router(complaints.router, prefix="/api")
app.include_router(dashboard.router, prefix="/api")
app.include_router(predictions.router, prefix="/api")
app.include_router(simulation.router, prefix="/api")
app.include_router(assistant.router, prefix="/api")
