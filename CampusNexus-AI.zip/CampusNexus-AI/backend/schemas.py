"""
Pydantic schemas for request/response validation.
"""
from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, Field


# ---------- Complaints ----------

class ComplaintCreate(BaseModel):
    text: str = Field(..., min_length=5, description="Raw complaint text in natural language")
    reporter_role: str = Field("student", description="student, faculty, or maintenance")


class ComplaintAnalyzeRequest(BaseModel):
    text: str = Field(..., min_length=5)


class ComplaintAnalyzeResponse(BaseModel):
    building: Optional[str] = None
    room: Optional[str] = None
    equipment: Optional[str] = None
    category: str
    problem: str
    severity: str
    urgency: str
    cluster_id: Optional[int] = None
    similar_complaints: List[dict] = []


class ComplaintOut(BaseModel):
    id: int
    raw_text: str
    building: Optional[str]
    room: Optional[str]
    equipment: Optional[str]
    category: Optional[str]
    problem: Optional[str]
    severity: Optional[str]
    urgency: Optional[str]
    cluster_id: Optional[int]
    reporter_role: str
    status: str
    created_at: datetime

    class Config:
        from_attributes = True


# ---------- Dashboard / Telemetry ----------

class BuildingStatus(BaseModel):
    building: str
    health_score: float
    electricity_kw: float
    water_flow_lpm: float
    occupancy: int
    temperature_c: float
    wifi_users: int
    risk_level: str
    latitude: float
    longitude: float


class DashboardSummary(BaseModel):
    campus_health_score: float
    total_buildings: int
    active_alerts: int
    high_risk_issues: int
    total_electricity_kw: float
    total_water_flow_lpm: float
    total_occupancy: int
    buildings: List[BuildingStatus]


# ---------- Predictions / Risk ----------

class RiskResult(BaseModel):
    building: str
    risk_type: str
    risk_score: float
    risk_level: str
    evidence: List[str]
    recommended_action: str


# ---------- Simulation ----------

class SimulationRequest(BaseModel):
    building: str
    occupancy: Optional[int] = None
    ac_usage_percent: Optional[float] = Field(None, ge=0, le=100)
    ac_temperature_c: Optional[float] = Field(None, ge=16, le=30)
    non_critical_equipment_on: Optional[bool] = None
    water_usage_percent: Optional[float] = Field(None, ge=0, le=200)


class SimulationResult(BaseModel):
    building: str
    before: dict
    after: dict
    difference: dict
    recommended_intervention: str


# ---------- Assistant ----------

class AssistantRequest(BaseModel):
    question: str = Field(..., min_length=2)


class AssistantResponse(BaseModel):
    answer: str
    source: str  # "local" or "llm"
    data: Optional[dict] = None
