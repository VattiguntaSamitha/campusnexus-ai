"""
SQLAlchemy ORM models for CampusNexus AI.

Tables: buildings, rooms, equipment, complaints, telemetry, predictions,
recommendations.
"""
from datetime import datetime

from sqlalchemy import (
    Column, Integer, String, Float, DateTime, ForeignKey, Text, Boolean
)
from sqlalchemy.orm import relationship

from backend.database import Base


class Building(Base):
    __tablename__ = "buildings"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, nullable=False, index=True)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    total_rooms = Column(Integer, default=0)
    year_built = Column(Integer, default=2005)

    rooms = relationship("Room", back_populates="building")
    equipment = relationship("Equipment", back_populates="building")
    telemetry = relationship("Telemetry", back_populates="building")


class Room(Base):
    __tablename__ = "rooms"

    id = Column(Integer, primary_key=True, index=True)
    building_id = Column(Integer, ForeignKey("buildings.id"), nullable=False)
    room_number = Column(String, nullable=False)
    room_type = Column(String, default="classroom")  # classroom, lab, office, hall
    capacity = Column(Integer, default=30)

    building = relationship("Building", back_populates="rooms")


class Equipment(Base):
    __tablename__ = "equipment"

    id = Column(Integer, primary_key=True, index=True)
    building_id = Column(Integer, ForeignKey("buildings.id"), nullable=False)
    room_number = Column(String, nullable=True)
    equipment_type = Column(String, nullable=False)  # AC, Chiller, Pump, Panel, Router...
    install_year = Column(Integer, default=2015)
    last_service_date = Column(DateTime, default=datetime.utcnow)
    health_score = Column(Float, default=90.0)  # 0-100, lower = worse
    previous_failures = Column(Integer, default=0)

    building = relationship("Building", back_populates="equipment")


class Complaint(Base):
    __tablename__ = "complaints"

    id = Column(Integer, primary_key=True, index=True)
    raw_text = Column(Text, nullable=False)
    building = Column(String, nullable=True)
    room = Column(String, nullable=True)
    equipment = Column(String, nullable=True)
    category = Column(String, nullable=True, index=True)
    problem = Column(String, nullable=True)
    severity = Column(String, nullable=True)
    urgency = Column(String, nullable=True)
    cluster_id = Column(Integer, nullable=True, index=True)
    reporter_role = Column(String, default="student")  # student, faculty, maintenance
    status = Column(String, default="OPEN")  # OPEN, IN_PROGRESS, RESOLVED
    created_at = Column(DateTime, default=datetime.utcnow, index=True)


class Telemetry(Base):
    __tablename__ = "telemetry"

    id = Column(Integer, primary_key=True, index=True)
    building_id = Column(Integer, ForeignKey("buildings.id"), nullable=False)
    timestamp = Column(DateTime, nullable=False, index=True)
    temperature_c = Column(Float, nullable=False)
    electricity_kw = Column(Float, nullable=False)
    water_flow_lpm = Column(Float, nullable=False)
    occupancy = Column(Integer, nullable=False)
    wifi_users = Column(Integer, nullable=False)
    hvac_on = Column(Boolean, default=True)

    building = relationship("Building", back_populates="telemetry")


class Prediction(Base):
    __tablename__ = "predictions"

    id = Column(Integer, primary_key=True, index=True)
    building = Column(String, nullable=False, index=True)
    risk_type = Column(String, nullable=False)  # HVAC, WATER, ELECTRICITY
    risk_score = Column(Float, nullable=False)
    risk_level = Column(String, nullable=False)  # LOW, MEDIUM, HIGH
    evidence_json = Column(Text, nullable=False)  # JSON-encoded list[str]
    created_at = Column(DateTime, default=datetime.utcnow, index=True)


class Recommendation(Base):
    __tablename__ = "recommendations"

    id = Column(Integer, primary_key=True, index=True)
    building = Column(String, nullable=False)
    risk_type = Column(String, nullable=False)
    message = Column(Text, nullable=False)
    priority = Column(String, default="MEDIUM")
    created_at = Column(DateTime, default=datetime.utcnow)
