"""
Endpoint: POST /api/assistant
"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from backend.database import get_db
from backend.schemas import AssistantRequest, AssistantResponse
from backend.services import assistant_service

router = APIRouter(tags=["assistant"])


@router.post("/assistant", response_model=AssistantResponse)
def ask_assistant(payload: AssistantRequest, db: Session = Depends(get_db)):
    """
    Ask the AI Campus Assistant a natural-language question. Uses a local,
    deterministic, database-backed assistant unless LLM_API_KEY is set in
    the environment, in which case it augments answers with a real LLM
    (still grounded in the same live campus data).
    """
    result = assistant_service.answer_question(db, payload.question)
    return result
