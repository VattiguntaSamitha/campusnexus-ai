"""
Endpoint: POST /api/simulate

Implements the What-If simulator: takes a building plus proposed changes
(occupancy, AC usage/temperature, non-critical equipment, water usage) and
recomputes electricity load and HVAC/electricity risk using the SAME
explainable formulas as the live risk engine, so results are trustworthy
and reproducible - never randomly generated.
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from backend.database import get_db
from backend import models
from backend.schemas import SimulationRequest, SimulationResult
from backend.services import telemetry_service
from ml.electricity_prediction import electricity_overload_evidence
from ml.risk_engine import score_to_level, recommended_action

router = APIRouter(tags=["simulation"])

# Simple, explainable physical assumptions used to translate simulator
# inputs into an electricity load estimate. These coefficients are
# intentionally transparent (not hidden inside a black-box model) so a
# beginner can read and tune them.
BASE_LOAD_KW = 8.0             # lighting, always-on systems
KW_PER_OCCUPANT = 0.045        # incremental load per person (devices, lighting)
KW_PER_AC_PERCENT = 0.18       # incremental load per 1% of AC usage
AC_TEMP_EFFICIENCY_KW = 0.6    # extra kW per degree BELOW 24°C (colder = more energy)
NON_CRITICAL_EQUIPMENT_KW = 6.0
WATER_BASE_LPM = 20.0
KW_PER_WATER_PERCENT_NOISE = 0.0  # water usage doesn't affect electricity; kept for clarity


def _estimate_electricity(occupancy: int, ac_usage_percent: float, ac_temperature_c: float,
                           non_critical_on: bool) -> float:
    load = BASE_LOAD_KW
    load += occupancy * KW_PER_OCCUPANT
    load += ac_usage_percent * KW_PER_AC_PERCENT
    if ac_temperature_c < 24:
        load += (24 - ac_temperature_c) * AC_TEMP_EFFICIENCY_KW
    if non_critical_on:
        load += NON_CRITICAL_EQUIPMENT_KW
    return round(max(load, 0.0), 1)


@router.post("/simulate", response_model=SimulationResult)
def simulate(payload: SimulationRequest, db: Session = Depends(get_db)):
    building = db.query(models.Building).filter(models.Building.name == payload.building).first()
    if not building:
        raise HTTPException(status_code=404, detail=f"Building '{payload.building}' not found")

    latest = telemetry_service.get_latest_reading(db, building.id)
    baseline = telemetry_service.get_baseline(db, building.id)

    # ---- BEFORE state: current live conditions ----
    before_occupancy = latest.occupancy if latest else int(baseline["occupancy"])
    before_hvac_on = latest.hvac_on if latest else True
    before_ac_percent = 70.0 if before_hvac_on else 0.0
    before_ac_temp = 20.0 if before_hvac_on else 26.0
    before_non_critical_on = True

    before_kw = _estimate_electricity(before_occupancy, before_ac_percent, before_ac_temp, before_non_critical_on)
    before_risk = electricity_overload_evidence(
        current_kw=before_kw, baseline_kw=baseline["electricity_kw"],
        occupancy_pct=min((before_occupancy / 300) * 100, 100),
        temperature_c=latest.temperature_c if latest else baseline["temperature_c"],
    )

    # ---- AFTER state: apply the user's proposed changes ----
    after_occupancy = payload.occupancy if payload.occupancy is not None else before_occupancy
    after_ac_percent = payload.ac_usage_percent if payload.ac_usage_percent is not None else before_ac_percent
    after_ac_temp = payload.ac_temperature_c if payload.ac_temperature_c is not None else before_ac_temp
    after_non_critical_on = (
        payload.non_critical_equipment_on if payload.non_critical_equipment_on is not None else before_non_critical_on
    )

    after_kw = _estimate_electricity(after_occupancy, after_ac_percent, after_ac_temp, after_non_critical_on)
    after_risk = electricity_overload_evidence(
        current_kw=after_kw, baseline_kw=baseline["electricity_kw"],
        occupancy_pct=min((after_occupancy / 300) * 100, 100),
        temperature_c=latest.temperature_c if latest else baseline["temperature_c"],
    )

    before_level = score_to_level(before_risk["score"])
    after_level = score_to_level(after_risk["score"])

    diff_kw = round(after_kw - before_kw, 1)
    diff_risk = round(after_risk["score"] - before_risk["score"], 1)

    if diff_risk < -10:
        intervention = f"These changes meaningfully reduce risk for {building.name} — recommended."
    elif diff_risk > 10:
        intervention = f"These changes increase risk for {building.name} — reconsider before applying."
    else:
        intervention = f"These changes have a modest effect on {building.name}'s risk profile."

    return SimulationResult(
        building=building.name,
        before={
            "electricity_kw": before_kw, "risk_score": before_risk["score"], "risk_level": before_level,
            "evidence": before_risk["evidence"], "occupancy": before_occupancy,
            "ac_usage_percent": before_ac_percent, "ac_temperature_c": before_ac_temp,
            "non_critical_equipment_on": before_non_critical_on,
        },
        after={
            "electricity_kw": after_kw, "risk_score": after_risk["score"], "risk_level": after_level,
            "evidence": after_risk["evidence"], "occupancy": after_occupancy,
            "ac_usage_percent": after_ac_percent, "ac_temperature_c": after_ac_temp,
            "non_critical_equipment_on": after_non_critical_on,
        },
        difference={"electricity_kw": diff_kw, "risk_score": diff_risk},
        recommended_intervention=intervention,
    )
