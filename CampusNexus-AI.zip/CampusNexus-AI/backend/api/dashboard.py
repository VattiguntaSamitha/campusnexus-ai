"""
Endpoints: GET /api/dashboard, GET /api/buildings, GET /api/telemetry,
GET /api/equipment, GET /api/water, GET /api/electricity
"""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from backend.database import get_db
from backend import models
from backend.schemas import DashboardSummary, BuildingStatus
from backend.services import telemetry_service, risk_engine

router = APIRouter(tags=["dashboard"])


def _building_status(db: Session, building: models.Building) -> BuildingStatus:
    latest = telemetry_service.get_latest_reading(db, building.id)
    risks = risk_engine.all_risks_for_building(db, building)
    max_risk_score = max((r["risk_score"] for r in risks), default=0)
    health_score = round(max(0, 100 - max_risk_score), 1)

    if max_risk_score >= 65:
        risk_level = "HIGH"
    elif max_risk_score >= 35:
        risk_level = "MEDIUM"
    else:
        risk_level = "LOW"

    return BuildingStatus(
        building=building.name,
        health_score=health_score,
        electricity_kw=latest.electricity_kw if latest else 0.0,
        water_flow_lpm=latest.water_flow_lpm if latest else 0.0,
        occupancy=latest.occupancy if latest else 0,
        temperature_c=latest.temperature_c if latest else 0.0,
        wifi_users=latest.wifi_users if latest else 0,
        risk_level=risk_level,
        latitude=building.latitude,
        longitude=building.longitude,
    )


@router.get("/dashboard", response_model=DashboardSummary)
def get_dashboard(db: Session = Depends(get_db)):
    """Full campus digital twin summary used by the main dashboard page."""
    buildings = db.query(models.Building).all()
    statuses = [_building_status(db, b) for b in buildings]

    campus_health = round(sum(s.health_score for s in statuses) / len(statuses), 1) if statuses else 100.0
    active_alerts = sum(1 for s in statuses if s.risk_level in ("MEDIUM", "HIGH"))
    high_risk_issues = sum(1 for s in statuses if s.risk_level == "HIGH")

    return DashboardSummary(
        campus_health_score=campus_health,
        total_buildings=len(statuses),
        active_alerts=active_alerts,
        high_risk_issues=high_risk_issues,
        total_electricity_kw=round(sum(s.electricity_kw for s in statuses), 1),
        total_water_flow_lpm=round(sum(s.water_flow_lpm for s in statuses), 1),
        total_occupancy=sum(s.occupancy for s in statuses),
        buildings=statuses,
    )


@router.get("/buildings")
def get_buildings(db: Session = Depends(get_db)):
    buildings = db.query(models.Building).all()
    return [
        {
            "id": b.id, "name": b.name, "latitude": b.latitude, "longitude": b.longitude,
            "total_rooms": b.total_rooms, "year_built": b.year_built,
        }
        for b in buildings
    ]


@router.get("/telemetry")
def get_telemetry(
    building: Optional[str] = None,
    hours: int = Query(48, ge=1, le=24 * 30),
    db: Session = Depends(get_db),
):
    """Recent telemetry series, optionally filtered to one building (for charts)."""
    query = db.query(models.Telemetry)
    if building:
        b = db.query(models.Building).filter(models.Building.name == building).first()
        if not b:
            raise HTTPException(status_code=404, detail=f"Building '{building}' not found")
        rows = telemetry_service.get_recent_series(db, b.id, hours=hours)
    else:
        rows = query.order_by(models.Telemetry.timestamp.desc()).limit(500).all()

    return [
        {
            "timestamp": r.timestamp.isoformat(),
            "building_id": r.building_id,
            "temperature_c": r.temperature_c,
            "electricity_kw": r.electricity_kw,
            "water_flow_lpm": r.water_flow_lpm,
            "occupancy": r.occupancy,
            "wifi_users": r.wifi_users,
            "hvac_on": r.hvac_on,
        }
        for r in rows
    ]


@router.get("/equipment")
def get_equipment(building: Optional[str] = None, db: Session = Depends(get_db)):
    query = db.query(models.Equipment).join(models.Building)
    if building:
        query = query.filter(models.Building.name == building)
    equipment = query.all()
    return [
        {
            "id": e.id, "building": e.building.name, "room_number": e.room_number,
            "equipment_type": e.equipment_type, "install_year": e.install_year,
            "health_score": e.health_score, "previous_failures": e.previous_failures,
        }
        for e in equipment
    ]


@router.get("/water")
def get_water_status(db: Session = Depends(get_db)):
    buildings = db.query(models.Building).all()
    return [risk_engine.water_risk_for_building(db, b) for b in buildings]


@router.get("/electricity")
def get_electricity_status(db: Session = Depends(get_db)):
    buildings = db.query(models.Building).all()
    return [risk_engine.electricity_risk_for_building(db, b) for b in buildings]
