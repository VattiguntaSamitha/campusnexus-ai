"""
Endpoints: GET /api/predictions, GET /api/risks, GET /api/recommendations
"""
from typing import List, Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from backend.database import get_db
from backend import models
from backend.schemas import RiskResult
from backend.services import risk_engine, recommendation_engine

router = APIRouter(tags=["predictions"])


@router.get("/risks", response_model=List[RiskResult])
def get_risks(building: Optional[str] = None, db: Session = Depends(get_db)):
    """Live, freshly-computed risk scores (HVAC/water/electricity) per building."""
    if building:
        b = db.query(models.Building).filter(models.Building.name == building).first()
        if not b:
            return []
        return risk_engine.all_risks_for_building(db, b)
    return risk_engine.all_campus_risks(db)


@router.get("/predictions", response_model=List[RiskResult])
def get_predictions(db: Session = Depends(get_db)):
    """
    Same as /risks, but also persists a snapshot to the `predictions` table
    and regenerates recommendations - useful for the Predictions page,
    which represents "running the models now".
    """
    risks = risk_engine.all_campus_risks(db)
    risk_engine.persist_predictions(db, risks)
    recommendation_engine.generate_recommendations(db, risks)
    return risks


@router.get("/recommendations")
def get_recommendations(db: Session = Depends(get_db), limit: int = Query(50, ge=1, le=200)):
    recs = recommendation_engine.list_recommendations(db, limit=limit)
    return [
        {
            "id": r.id, "building": r.building, "risk_type": r.risk_type,
            "message": r.message, "priority": r.priority, "created_at": r.created_at.isoformat(),
        }
        for r in recs
    ]
