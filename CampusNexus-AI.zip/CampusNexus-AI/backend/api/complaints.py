"""
Endpoints: GET /api/complaints, POST /api/complaints, POST /api/analyze-complaint
"""
from typing import List, Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from backend.database import get_db
from backend.schemas import ComplaintCreate, ComplaintOut, ComplaintAnalyzeRequest, ComplaintAnalyzeResponse
from backend.services import complaint_service

router = APIRouter(tags=["complaints"])


@router.get("/complaints", response_model=List[ComplaintOut])
def get_complaints(
    limit: int = Query(100, ge=1, le=500),
    category: Optional[str] = None,
    building: Optional[str] = None,
    db: Session = Depends(get_db),
):
    """Return recent complaints, optionally filtered by category/building."""
    return complaint_service.list_complaints(db, limit=limit, category=category, building=building)


@router.post("/complaints", response_model=ComplaintOut)
def submit_complaint(payload: ComplaintCreate, db: Session = Depends(get_db)):
    """Submit a new natural-language complaint. Runs the full NLP pipeline and stores it."""
    complaint = complaint_service.create_complaint(db, payload.text, payload.reporter_role)
    return complaint


@router.post("/analyze-complaint", response_model=ComplaintAnalyzeResponse)
def analyze_complaint_endpoint(payload: ComplaintAnalyzeRequest, db: Session = Depends(get_db)):
    """
    Analyze complaint text WITHOUT saving it - used by the frontend to show
    a live preview of extracted entities and similar historical complaints.
    """
    result = complaint_service.analyze_and_find_similar(db, payload.text)
    return result
