"""
Orchestrates the explainable risk engine: pulls live telemetry + complaint
history from the database and combines them with the ml/ scoring modules
to produce HVAC, water, and electricity risk scores with evidence.

This is the module that guarantees "every prediction must come from a
trained ML model OR an explainable deterministic analytics/risk engine" -
predictions are recomputed from real data, never randomly generated.
"""
from datetime import datetime
from typing import List, Dict
from sqlalchemy.orm import Session

from backend import models
from backend.services import telemetry_service, complaint_service
from ml.equipment_failure import equipment_failure_risk, equipment_age_years
from ml.water_anomaly import water_anomaly_risk
from ml.electricity_prediction import electricity_overload_evidence
from ml.risk_engine import score_to_level, recommended_action, combine_evidence


def hvac_risk_for_building(db: Session, building: models.Building) -> Dict:
    """Combine complaint frequency + equipment condition + temperature delta."""
    latest = telemetry_service.get_latest_reading(db, building.id)
    baseline = telemetry_service.get_baseline(db, building.id)

    complaint_count = complaint_service.recent_complaint_count(db, building.name, "HVAC")

    hvac_equipment = (
        db.query(models.Equipment)
        .filter(models.Equipment.building_id == building.id,
                models.Equipment.equipment_type.in_(["AC", "Chiller"]))
        .all()
    )

    if hvac_equipment:
        # Use the least healthy unit as the representative risk driver.
        worst = min(hvac_equipment, key=lambda e: e.health_score)
        age = equipment_age_years(worst.install_year)
        health = worst.health_score
        previous_failures = worst.previous_failures
    else:
        age, health, previous_failures = 5.0, 85.0, 0

    current_temp = latest.temperature_c if latest else baseline["temperature_c"]

    result = equipment_failure_risk(
        complaint_count_recent=complaint_count,
        equipment_age_years=age,
        health_score=health,
        previous_failures=previous_failures,
        current_temperature_c=current_temp,
        baseline_temperature_c=baseline["temperature_c"],
    )

    level = score_to_level(result["score"])
    return {
        "building": building.name,
        "risk_type": "HVAC",
        "risk_score": result["score"],
        "risk_level": level,
        "evidence": result["evidence"] or ["No significant HVAC risk indicators detected"],
        "recommended_action": recommended_action("HVAC", building.name, level),
    }


def water_risk_for_building(db: Session, building: models.Building) -> Dict:
    latest = telemetry_service.get_latest_reading(db, building.id)
    baseline = telemetry_service.get_baseline(db, building.id)

    if not latest:
        current_flow, current_occ, hour = baseline["water_flow_lpm"], int(baseline["occupancy"]), 12
    else:
        current_flow, current_occ, hour = latest.water_flow_lpm, latest.occupancy, latest.timestamp.hour

    result = water_anomaly_risk(
        current_flow_lpm=current_flow,
        baseline_flow_lpm=baseline["water_flow_lpm"],
        occupancy=current_occ,
        baseline_occupancy=int(baseline["occupancy"]),
        hour_of_day=hour,
    )

    level = score_to_level(result["score"])
    return {
        "building": building.name,
        "risk_type": "WATER",
        "risk_score": result["score"],
        "risk_level": level,
        "evidence": result["evidence"] or ["No significant water anomaly detected"],
        "recommended_action": recommended_action("WATER", building.name, level),
    }


def electricity_risk_for_building(db: Session, building: models.Building) -> Dict:
    latest = telemetry_service.get_latest_reading(db, building.id)
    baseline = telemetry_service.get_baseline(db, building.id)

    if not latest:
        current_kw, occupancy, temp = baseline["electricity_kw"], baseline["occupancy"], baseline["temperature_c"]
        capacity = max(occupancy, 1)
    else:
        current_kw, occupancy, temp = latest.electricity_kw, latest.occupancy, latest.temperature_c
        capacity = 300  # matches max synthetic occupancy scale

    occupancy_pct = min((occupancy / capacity) * 100, 100)

    result = electricity_overload_evidence(
        current_kw=current_kw,
        baseline_kw=baseline["electricity_kw"],
        occupancy_pct=occupancy_pct,
        temperature_c=temp,
    )

    level = score_to_level(result["score"])
    return {
        "building": building.name,
        "risk_type": "ELECTRICITY",
        "risk_score": result["score"],
        "risk_level": level,
        "evidence": result["evidence"] or ["Electricity usage within normal range"],
        "recommended_action": recommended_action("ELECTRICITY", building.name, level),
    }


def all_risks_for_building(db: Session, building: models.Building) -> List[Dict]:
    return [
        hvac_risk_for_building(db, building),
        water_risk_for_building(db, building),
        electricity_risk_for_building(db, building),
    ]


def all_campus_risks(db: Session) -> List[Dict]:
    buildings = db.query(models.Building).all()
    risks = []
    for b in buildings:
        risks.extend(all_risks_for_building(db, b))
    return risks


def persist_predictions(db: Session, risks: List[Dict]) -> None:
    """Save computed risk results as Prediction rows (used by /api/predictions)."""
    import json
    for r in risks:
        db.add(models.Prediction(
            building=r["building"],
            risk_type=r["risk_type"],
            risk_score=r["risk_score"],
            risk_level=r["risk_level"],
            evidence_json=json.dumps(r["evidence"]),
            created_at=datetime.utcnow(),
        ))
    db.commit()
