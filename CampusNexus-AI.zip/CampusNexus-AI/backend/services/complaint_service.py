"""
Business logic for complaints: analysis, similarity search, storage.
"""
from typing import List, Dict, Any
from sqlalchemy.orm import Session

from backend import models
from nlp.pipeline import analyze_complaint, find_similar_complaints
from nlp.clustering import cluster_complaints


def analyze_and_find_similar(db: Session, text: str) -> Dict[str, Any]:
    """
    Run the NLP pipeline on new complaint text and compare it against
    recent historical complaints to find likely duplicates/related issues.
    """
    result = analyze_complaint(text)

    # Pull recent complaints (same category if we have one, for a tighter,
    # faster comparison set) to check for similar/duplicate issues.
    query = db.query(models.Complaint)
    if result["category"]:
        query = query.filter(models.Complaint.category == result["category"])
    recent_complaints = query.order_by(models.Complaint.created_at.desc()).limit(200).all()

    historical_texts = [c.raw_text for c in recent_complaints]
    matches = find_similar_complaints(text, historical_texts, top_k=5)

    similar_complaints = []
    cluster_id = None
    for m in matches:
        complaint = recent_complaints[m["index"]]
        similar_complaints.append({
            "id": complaint.id,
            "text": complaint.raw_text,
            "similarity": m["similarity"],
            "building": complaint.building,
            "room": complaint.room,
            "created_at": complaint.created_at.isoformat(),
        })
        if cluster_id is None and complaint.cluster_id is not None:
            cluster_id = complaint.cluster_id

    result["cluster_id"] = cluster_id
    result["similar_complaints"] = similar_complaints
    return result


def create_complaint(db: Session, text: str, reporter_role: str) -> models.Complaint:
    """Analyze a new complaint, assign it to a cluster, and persist it."""
    analysis = analyze_and_find_similar(db, text)

    complaint = models.Complaint(
        raw_text=text,
        building=analysis["building"],
        room=analysis["room"],
        equipment=analysis["equipment"],
        category=analysis["category"],
        problem=analysis["problem"],
        severity=analysis["severity"],
        urgency=analysis["urgency"],
        cluster_id=analysis["cluster_id"],
        reporter_role=reporter_role,
        status="OPEN",
    )
    db.add(complaint)
    db.commit()
    db.refresh(complaint)

    # If this complaint didn't match an existing cluster, give it a new one
    # that doesn't collide with existing cluster ids.
    if complaint.cluster_id is None:
        max_cluster = db.query(models.Complaint.cluster_id).order_by(
            models.Complaint.cluster_id.desc()
        ).first()
        next_cluster_id = (max_cluster[0] + 1) if max_cluster and max_cluster[0] is not None else 0
        complaint.cluster_id = next_cluster_id
        db.commit()
        db.refresh(complaint)

    return complaint


def list_complaints(db: Session, limit: int = 100, category: str = None,
                     building: str = None) -> List[models.Complaint]:
    query = db.query(models.Complaint)
    if category:
        query = query.filter(models.Complaint.category == category)
    if building:
        query = query.filter(models.Complaint.building == building)
    return query.order_by(models.Complaint.created_at.desc()).limit(limit).all()


def recent_complaint_count(db: Session, building: str, category: str, days: int = 14) -> int:
    from datetime import datetime, timedelta
    cutoff = datetime.utcnow() - timedelta(days=days)
    return db.query(models.Complaint).filter(
        models.Complaint.building == building,
        models.Complaint.category == category,
        models.Complaint.created_at >= cutoff,
    ).count()
