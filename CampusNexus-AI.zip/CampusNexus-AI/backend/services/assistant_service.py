"""
AI Campus Assistant.

Default mode (no API key configured): a deterministic, intent-based
assistant that answers by querying the real database - never hardcoded
text with no data behind it.

Optional mode: if LLM_API_KEY is set, the assistant instead sends the
user's question PLUS a real data summary to an external LLM so it can
phrase a more natural answer. If that call fails for any reason (bad key,
no internet, provider error), it automatically falls back to the local
assistant so the app never breaks.
"""
import json
import logging
from typing import Dict
import requests
from sqlalchemy.orm import Session

from backend import models
from backend.config import LLM_API_KEY, LLM_PROVIDER
from backend.services import risk_engine, complaint_service, recommendation_engine

logger = logging.getLogger("campusnexus.assistant")


def _campus_context(db: Session) -> Dict:
    """Gather a compact snapshot of current campus data for the assistant to reason over."""
    risks = risk_engine.all_campus_risks(db)
    top_risks = sorted(risks, key=lambda r: r["risk_score"], reverse=True)[:8]

    recent_complaints = complaint_service.list_complaints(db, limit=20)
    recommendations = recommendation_engine.list_recommendations(db, limit=10)

    return {
        "top_risks": top_risks,
        "recent_complaints": [
            {"building": c.building, "category": c.category, "severity": c.severity, "text": c.raw_text}
            for c in recent_complaints
        ],
        "recommendations": [
            {"building": r.building, "risk_type": r.risk_type, "message": r.message} for r in recommendations
        ],
    }


def _local_answer(question: str, context: Dict) -> str:
    """Rule-based intent matching over the real campus data snapshot."""
    q = question.lower()
    risks = context["top_risks"]

    def highest_risk(risk_type=None):
        candidates = [r for r in risks if risk_type is None or r["risk_type"] == risk_type]
        return max(candidates, key=lambda r: r["risk_score"]) if candidates else None

    if "biggest problem" in q or "top problem" in q or "worst" in q:
        top = highest_risk()
        if top:
            return (f"The biggest concern right now is {top['risk_type']} risk in {top['building']} "
                     f"at {top['risk_score']:.0f}% ({top['risk_level']}). "
                     f"Evidence: {'; '.join(top['evidence'])}.")
        return "No significant risks are currently detected across campus."

    if "highest risk" in q or "which building" in q:
        top = highest_risk()
        if top:
            return f"{top['building']} currently has the highest risk: {top['risk_type']} at {top['risk_score']:.0f}% ({top['risk_level']})."
        return "All buildings are currently within normal risk levels."

    if "electricity" in q or "power" in q:
        top = highest_risk("ELECTRICITY")
        if top:
            return (f"Electricity risk is highest in {top['building']} at {top['risk_score']:.0f}% "
                     f"({top['risk_level']}). Evidence: {'; '.join(top['evidence'])}.")
        return "No electricity anomalies detected right now."

    if "water" in q or "leak" in q:
        top = highest_risk("WATER")
        if top and top["risk_score"] > 20:
            return (f"Possible water issue detected in {top['building']}: risk {top['risk_score']:.0f}% "
                     f"({top['risk_level']}). Evidence: {'; '.join(top['evidence'])}.")
        return "No signs of water leaks detected currently."

    if "hvac" in q or "ac " in q or "air condition" in q:
        hvac_risks = [r for r in risks if r["risk_type"] == "HVAC"]
        if hvac_risks:
            lines = [f"{r['building']}: {r['risk_score']:.0f}% ({r['risk_level']})" for r in hvac_risks]
            return "HVAC risk by building — " + "; ".join(lines)
        return "No HVAC risk data currently available."

    if "inspect" in q or "maintenance" in q or "should" in q:
        recs = context["recommendations"]
        if recs:
            return "Maintenance priorities: " + " | ".join(r["message"] for r in recs[:3])
        return "No urgent maintenance actions are currently recommended."

    # Default: general campus status summary.
    if risks:
        top = risks[0]
        return (f"Campus overview: {len(context['recent_complaints'])} recent complaints on file. "
                 f"Top risk is {top['risk_type']} in {top['building']} at {top['risk_score']:.0f}%. "
                 "Ask about a specific building, HVAC, water, or electricity for more detail.")
    return "Campus systems currently look normal. Ask me about a specific building or issue type."


def _llm_answer(question: str, context: Dict) -> str:
    """Call an external LLM with the real data context. Raises on failure (caller catches it)."""
    system_prompt = (
        "You are a campus operations assistant. Answer the administrator's question "
        "using ONLY the JSON campus data provided. Be concise and specific, quoting "
        "risk percentages and building names where relevant."
    )
    user_content = f"Campus data:\n{json.dumps(context)}\n\nQuestion: {question}"

    if LLM_PROVIDER == "openai":
        response = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers={"Authorization": f"Bearer {LLM_API_KEY}", "Content-Type": "application/json"},
            json={
                "model": "gpt-4o-mini",
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_content},
                ],
                "max_tokens": 300,
            },
            timeout=15,
        )
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"].strip()

    if LLM_PROVIDER == "anthropic":
        response = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={"x-api-key": LLM_API_KEY, "anthropic-version": "2023-06-01",
                      "Content-Type": "application/json"},
            json={
                "model": "claude-sonnet-4-6",
                "max_tokens": 300,
                "system": system_prompt,
                "messages": [{"role": "user", "content": user_content}],
            },
            timeout=15,
        )
        response.raise_for_status()
        return response.json()["content"][0]["text"].strip()

    raise ValueError(f"Unsupported LLM_PROVIDER: {LLM_PROVIDER}")


def answer_question(db: Session, question: str) -> Dict:
    """Main entry point used by the /api/assistant endpoint."""
    context = _campus_context(db)

    if LLM_API_KEY:
        try:
            answer = _llm_answer(question, context)
            return {"answer": answer, "source": "llm", "data": context}
        except Exception as exc:  # noqa: BLE001 - intentional broad catch for graceful fallback
            logger.warning("LLM call failed (%s); falling back to local assistant.", exc)

    answer = _local_answer(question, context)
    return {"answer": answer, "source": "local", "data": context}
