"""
Turns risk engine output into stored, actionable recommendations, and
provides read access to them for the dashboard and assistant.
"""
from typing import List, Dict
from sqlalchemy.orm import Session

from backend import models


def generate_recommendations(db: Session, risks: List[Dict]) -> List[models.Recommendation]:
    """
    Create Recommendation rows for any risk at MEDIUM or HIGH level.
    Avoids duplicate spam by skipping if an identical open recommendation
    already exists for that building + risk_type.
    """
    created = []
    for r in risks:
        if r["risk_level"] == "LOW":
            continue

        existing = (
            db.query(models.Recommendation)
            .filter(models.Recommendation.building == r["building"],
                     models.Recommendation.risk_type == r["risk_type"])
            .order_by(models.Recommendation.created_at.desc())
            .first()
        )
        if existing and existing.message == r["recommended_action"]:
            continue

        rec = models.Recommendation(
            building=r["building"],
            risk_type=r["risk_type"],
            message=r["recommended_action"],
            priority=r["risk_level"],
        )
        db.add(rec)
        created.append(rec)

    if created:
        db.commit()
        for rec in created:
            db.refresh(rec)
    return created


def list_recommendations(db: Session, limit: int = 50) -> List[models.Recommendation]:
    return (
        db.query(models.Recommendation)
        .order_by(models.Recommendation.created_at.desc())
        .limit(limit)
        .all()
    )
