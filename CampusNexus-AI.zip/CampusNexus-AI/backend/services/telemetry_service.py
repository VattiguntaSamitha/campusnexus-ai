"""
Telemetry access + aggregation helpers used by the dashboard, predictions,
and simulator.
"""
from datetime import datetime, timedelta
from typing import Optional, Dict, List
from sqlalchemy.orm import Session
from sqlalchemy import func

from backend import models


def get_latest_reading(db: Session, building_id: int) -> Optional[models.Telemetry]:
    return (
        db.query(models.Telemetry)
        .filter(models.Telemetry.building_id == building_id)
        .order_by(models.Telemetry.timestamp.desc())
        .first()
    )


def get_baseline(db: Session, building_id: int, days: int = 14) -> Dict[str, float]:
    """
    Compute average telemetry values over the last `days` days, excluding
    the most recent 24 hours (so a live anomaly doesn't pollute its own
    baseline).
    """
    now = datetime.utcnow()
    window_start = now - timedelta(days=days)
    window_end = now - timedelta(hours=24)

    result = (
        db.query(
            func.avg(models.Telemetry.temperature_c),
            func.avg(models.Telemetry.electricity_kw),
            func.avg(models.Telemetry.water_flow_lpm),
            func.avg(models.Telemetry.occupancy),
        )
        .filter(
            models.Telemetry.building_id == building_id,
            models.Telemetry.timestamp >= window_start,
            models.Telemetry.timestamp <= window_end,
        )
        .first()
    )

    temp, elec, water, occ = result
    return {
        "temperature_c": float(temp) if temp is not None else 25.0,
        "electricity_kw": float(elec) if elec is not None else 20.0,
        "water_flow_lpm": float(water) if water is not None else 25.0,
        "occupancy": float(occ) if occ is not None else 50.0,
    }


def get_recent_series(db: Session, building_id: int, hours: int = 48) -> List[models.Telemetry]:
    cutoff = datetime.utcnow() - timedelta(hours=hours)
    return (
        db.query(models.Telemetry)
        .filter(models.Telemetry.building_id == building_id, models.Telemetry.timestamp >= cutoff)
        .order_by(models.Telemetry.timestamp.asc())
        .all()
    )
