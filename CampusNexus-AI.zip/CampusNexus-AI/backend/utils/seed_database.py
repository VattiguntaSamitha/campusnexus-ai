"""
Thin wrapper so the FastAPI app can ensure the database is seeded on
startup (if it's empty) without duplicating the seeding logic that lives
in scripts/seed.py.
"""
import logging
from backend.database import SessionLocal
from backend import models

logger = logging.getLogger("campusnexus.startup")


def seed_if_empty() -> None:
    """If the buildings table is empty, run the full seed process."""
    db = SessionLocal()
    try:
        count = db.query(models.Building).count()
    finally:
        db.close()

    if count == 0:
        logger.info("Database is empty - running first-time seed...")
        from scripts.seed import seed_database
        seed_database()
    else:
        logger.info("Database already contains data (%d buildings) - skipping seed.", count)
