"""
Generates all synthetic demo data for CampusNexus AI and writes it to /data
as CSV files:
    campus_buildings.csv, rooms.csv, equipment.csv, complaints.csv, telemetry.csv

Includes intentional anomalies so the ML/risk engine has something real to
detect:
    1. Block B: HVAC problems (aging AC units, complaint spike, hot rooms)
    2. Block C: water leakage (elevated night-time water flow)
    3. Block B: electricity overload (sustained high draw)

Run with: python scripts/generate_data.py
"""
import os
import sys
import random
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.config import BUILDINGS, DATA_DIR, CATEGORIES  # noqa: E402

random.seed(42)
np.random.seed(42)

N_ROOMS = 50
N_EQUIPMENT = 40
N_COMPLAINTS = 500
TELEMETRY_DAYS = 35  # ~5000 rows across 6 buildings at ~4hr resolution -> increase freq below

# Buildings with rough campus-relative coordinates for the map.
BUILDING_COORDS = {
    "Block A": (28.6139, 77.2090),
    "Block B": (28.6142, 77.2100),
    "Block C": (28.6148, 77.2085),
    "Library": (28.6135, 77.2095),
    "Laboratory Block": (28.6150, 77.2105),
    "Administration Block": (28.6130, 77.2080),
}

ROOM_TYPES = ["classroom", "lab", "office", "hall"]

EQUIPMENT_TYPES = ["AC", "Chiller", "Water Pump", "Electrical Panel", "Wi-Fi Router",
                    "Generator", "Elevator", "Water Heater"]

# ---------- Complaint text templates (used to build realistic natural language) ----------

HVAC_TEMPLATES = [
    "The AC in {building} room {room} is making strange noise and the room is very hot.",
    "Air conditioner in room {room}, {building} isn't working, it's not cooling at all.",
    "Room {room} in {building} is very hot, the AC seems broken.",
    "Chiller unit near {building} is making a loud rattling sound.",
    "The AC in {building} room {room} is leaking water onto the floor.",
    "Room {room} temperature is uncomfortable, cooling seems very weak.",
]
WATER_TEMPLATES = [
    "There is a water leak near the washroom in {building}.",
    "Water is dripping from the ceiling in room {room}, {building}.",
    "The tap in {building} restroom won't stop running.",
    "Pipe burst near {building} ground floor, water everywhere.",
    "Water pressure is very low in {building} room {room}.",
]
ELECTRICITY_TEMPLATES = [
    "Power socket in room {room}, {building} is sparking.",
    "Frequent power outages in {building} over the last two days.",
    "The lights keep flickering in {building} room {room}.",
    "Electrical panel in {building} is making a buzzing noise.",
    "Circuit breaker in {building} trips constantly.",
]
NETWORK_TEMPLATES = [
    "Wi-Fi is extremely slow in {building} room {room}.",
    "No internet connectivity in the {building} today.",
    "Wi-Fi router in {building} keeps disconnecting.",
]
EQUIPMENT_TEMPLATES = [
    "The projector in room {room}, {building} is not turning on.",
    "Elevator in {building} is stuck between floors.",
    "Printer in {building} office is jammed and unusable.",
]
SANITATION_TEMPLATES = [
    "Washroom in {building} is very dirty and needs cleaning.",
    "There is a bad smell coming from the restroom in {building}.",
    "Garbage has not been collected in {building} for days.",
]
SECURITY_TEMPLATES = [
    "CCTV camera outside {building} is not working.",
    "The main door lock in {building} is broken.",
    "Suspicious person seen loitering near {building} entrance.",
]
OTHER_TEMPLATES = [
    "General maintenance needed in {building} room {room}.",
    "Furniture is broken in room {room}, {building}.",
]

TEMPLATE_MAP = {
    "HVAC": HVAC_TEMPLATES,
    "WATER": WATER_TEMPLATES,
    "ELECTRICITY": ELECTRICITY_TEMPLATES,
    "NETWORK": NETWORK_TEMPLATES,
    "EQUIPMENT": EQUIPMENT_TEMPLATES,
    "SANITATION": SANITATION_TEMPLATES,
    "SECURITY": SECURITY_TEMPLATES,
    "OTHER": OTHER_TEMPLATES,
}

# Weighted category distribution. Block B gets extra HVAC weight (anomaly #1).
CATEGORY_WEIGHTS = [0.28, 0.14, 0.14, 0.10, 0.12, 0.10, 0.07, 0.05]  # sums to 1.0, matches CATEGORIES order


def generate_buildings() -> pd.DataFrame:
    rows = []
    for i, name in enumerate(BUILDINGS):
        lat, lon = BUILDING_COORDS[name]
        rows.append({
            "id": i + 1,
            "name": name,
            "latitude": lat,
            "longitude": lon,
            "total_rooms": 0,  # filled in after rooms are generated
            "year_built": random.randint(1985, 2015),
        })
    return pd.DataFrame(rows)


def generate_rooms(buildings_df: pd.DataFrame, n_rooms: int = N_ROOMS) -> pd.DataFrame:
    rows = []
    room_id = 1
    rooms_per_building = n_rooms // len(buildings_df)
    for _, b in buildings_df.iterrows():
        for i in range(rooms_per_building):
            floor = (i // 5) + 1
            room_number = f"{floor}{i % 5:02d}"
            rows.append({
                "id": room_id,
                "building_id": b["id"],
                "room_number": room_number,
                "room_type": random.choice(ROOM_TYPES),
                "capacity": random.choice([25, 30, 40, 60, 100]),
            })
            room_id += 1
    # Distribute any remainder rooms to the first building.
    remaining = n_rooms - len(rows)
    for i in range(remaining):
        rows.append({
            "id": room_id,
            "building_id": buildings_df.iloc[0]["id"],
            "room_number": f"9{i:02d}",
            "room_type": random.choice(ROOM_TYPES),
            "capacity": random.choice([25, 30, 40]),
        })
        room_id += 1
    return pd.DataFrame(rows)


def generate_equipment(buildings_df: pd.DataFrame, rooms_df: pd.DataFrame,
                        n_equipment: int = N_EQUIPMENT) -> pd.DataFrame:
    rows = []
    for eq_id in range(1, n_equipment + 1):
        building = buildings_df.sample(1, random_state=eq_id).iloc[0]
        building_rooms = rooms_df[rooms_df["building_id"] == building["id"]]
        room = building_rooms.sample(1, random_state=eq_id).iloc[0] if len(building_rooms) else None

        equipment_type = random.choice(EQUIPMENT_TYPES)
        install_year = random.randint(2008, 2023)

        # --- Intentional anomaly #1: Block B HVAC units are old & unhealthy ---
        if building["name"] == "Block B" and equipment_type in ("AC", "Chiller"):
            install_year = random.randint(2008, 2013)  # older units
            health_score = random.uniform(35, 55)
            previous_failures = random.randint(1, 3)
        else:
            health_score = random.uniform(70, 98)
            previous_failures = random.choice([0, 0, 0, 1])

        rows.append({
            "id": eq_id,
            "building_id": building["id"],
            "room_number": room["room_number"] if room is not None else None,
            "equipment_type": equipment_type,
            "install_year": install_year,
            "last_service_date": (datetime.utcnow() - timedelta(days=random.randint(10, 400))).isoformat(),
            "health_score": round(health_score, 1),
            "previous_failures": previous_failures,
        })
    return pd.DataFrame(rows)


def _fill_template(template: str, building: str, room: str) -> str:
    return template.format(building=building, room=room)


def generate_complaints(buildings_df: pd.DataFrame, rooms_df: pd.DataFrame,
                         n_complaints: int = N_COMPLAINTS) -> pd.DataFrame:
    rows = []
    roles = ["student", "faculty", "maintenance"]
    now = datetime.utcnow()

    for i in range(1, n_complaints + 1):
        # --- Intentional anomaly #1: Block B gets extra HVAC complaints ---
        if i <= n_complaints * 0.12:
            building_name = "Block B"
            category = "HVAC"
        else:
            building_name = random.choice(buildings_df["name"].tolist())
            category = random.choices(CATEGORIES, weights=CATEGORY_WEIGHTS, k=1)[0]

        building_rooms = rooms_df[rooms_df["building_id"] ==
                                   buildings_df[buildings_df["name"] == building_name]["id"].iloc[0]]
        room = building_rooms.sample(1, random_state=i).iloc[0]["room_number"] if len(building_rooms) else "101"

        template = random.choice(TEMPLATE_MAP[category])
        text = _fill_template(template, building_name, room)

        days_ago = random.randint(0, 60)
        created_at = now - timedelta(days=days_ago, hours=random.randint(0, 23))

        rows.append({
            "id": i,
            "raw_text": text,
            "building": building_name,
            "room": room,
            "category": category,
            "reporter_role": random.choice(roles),
            "status": random.choice(["OPEN", "OPEN", "IN_PROGRESS", "RESOLVED"]),
            "created_at": created_at.isoformat(),
        })
    return pd.DataFrame(rows)


def generate_telemetry(buildings_df: pd.DataFrame, days: int = TELEMETRY_DAYS) -> pd.DataFrame:
    rows = []
    now = datetime.utcnow()
    start = now - timedelta(days=days)
    # Hourly readings for `days` days across all buildings gives
    # days * 24 * n_buildings rows. With days=35 and 6 buildings -> 5040 rows.
    timestamps = pd.date_range(start=start, end=now, freq="h")

    row_id = 1
    for _, b in buildings_df.iterrows():
        base_temp = random.uniform(24, 27)
        base_elec = random.uniform(15, 25)
        base_water = random.uniform(20, 40)

        for ts in timestamps:
            hour = ts.hour
            # Daytime (8am-6pm) has more occupancy/activity.
            is_daytime = 8 <= hour <= 18
            occupancy = int(np.clip(np.random.normal(120 if is_daytime else 10, 25), 0, 300))
            wifi_users = int(np.clip(occupancy * random.uniform(0.6, 1.1), 0, 400))
            temperature = base_temp + (3 if is_daytime else -1) + np.random.normal(0, 1.2)
            hvac_on = is_daytime and temperature > 26

            electricity = base_elec + (occupancy * 0.05) + (8 if hvac_on else 0) + np.random.normal(0, 1.5)
            water_flow = base_water * (0.3 if not is_daytime else 1.0) + np.random.normal(0, 2)
            water_flow = max(water_flow, 0)

            # --- Intentional anomaly #2: Block C water leakage (elevated
            # night-time flow that shouldn't happen with near-zero occupancy) ---
            if b["name"] == "Block C" and ts >= now - timedelta(days=4):
                if not is_daytime:
                    water_flow += random.uniform(25, 45)

            # --- Intentional anomaly #3: Block B electricity overload
            # (sustained high draw in the last 3 days) ---
            if b["name"] == "Block B" and ts >= now - timedelta(days=3):
                electricity += random.uniform(15, 28)

            rows.append({
                "id": row_id,
                "building_id": b["id"],
                "timestamp": ts.isoformat(),
                "temperature_c": round(float(temperature), 1),
                "electricity_kw": round(float(max(electricity, 0)), 2),
                "water_flow_lpm": round(float(water_flow), 2),
                "occupancy": occupancy,
                "wifi_users": wifi_users,
                "hvac_on": bool(hvac_on),
            })
            row_id += 1
    return pd.DataFrame(rows)


def main():
    os.makedirs(DATA_DIR, exist_ok=True)

    print("Generating buildings...")
    buildings_df = generate_buildings()

    print("Generating rooms...")
    rooms_df = generate_rooms(buildings_df)
    buildings_df["total_rooms"] = buildings_df["id"].apply(
        lambda bid: len(rooms_df[rooms_df["building_id"] == bid])
    )

    print("Generating equipment...")
    equipment_df = generate_equipment(buildings_df, rooms_df)

    print("Generating complaints...")
    complaints_df = generate_complaints(buildings_df, rooms_df)

    print("Generating telemetry (this creates several thousand rows, please wait)...")
    telemetry_df = generate_telemetry(buildings_df)

    buildings_df.to_csv(os.path.join(DATA_DIR, "campus_buildings.csv"), index=False)
    rooms_df.to_csv(os.path.join(DATA_DIR, "rooms.csv"), index=False)
    equipment_df.to_csv(os.path.join(DATA_DIR, "equipment.csv"), index=False)
    complaints_df.to_csv(os.path.join(DATA_DIR, "complaints.csv"), index=False)
    telemetry_df.to_csv(os.path.join(DATA_DIR, "telemetry.csv"), index=False)

    print(f"Done. Buildings={len(buildings_df)}, Rooms={len(rooms_df)}, "
          f"Equipment={len(equipment_df)}, Complaints={len(complaints_df)}, "
          f"Telemetry={len(telemetry_df)}")


if __name__ == "__main__":
    main()
