"""
Loads the CSV files from /data into the SQLite database.

If the CSVs don't exist yet, this script generates them first by calling
scripts/generate_data.py. Safe to re-run: it clears existing rows in the
relevant tables before reloading, so you always get a clean, consistent
dataset.

Run with: python scripts/seed.py
"""
import os
import sys
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.config import DATA_DIR  # noqa: E402
from backend.database import engine, SessionLocal, init_db  # noqa: E402
from backend import models  # noqa: E402


def _ensure_csvs_exist():
    required = ["campus_buildings.csv", "rooms.csv", "equipment.csv", "complaints.csv", "telemetry.csv"]
    missing = [f for f in required if not os.path.exists(os.path.join(DATA_DIR, f))]
    if missing:
        print(f"Missing data files {missing}. Generating synthetic data first...")
        from scripts.generate_data import main as generate_main
        generate_main()


def seed_database():
    _ensure_csvs_exist()
    init_db()

    db = SessionLocal()
    try:
        print("Clearing existing data...")
        for model in [models.Recommendation, models.Prediction, models.Complaint,
                      models.Telemetry, models.Equipment, models.Room, models.Building]:
            db.query(model).delete()
        db.commit()

        print("Loading buildings...")
        buildings_df = pd.read_csv(os.path.join(DATA_DIR, "campus_buildings.csv"))
        for _, row in buildings_df.iterrows():
            db.add(models.Building(
                id=int(row["id"]), name=row["name"], latitude=float(row["latitude"]),
                longitude=float(row["longitude"]), total_rooms=int(row["total_rooms"]),
                year_built=int(row["year_built"]),
            ))
        db.commit()

        print("Loading rooms...")
        rooms_df = pd.read_csv(os.path.join(DATA_DIR, "rooms.csv"))
        for _, row in rooms_df.iterrows():
            db.add(models.Room(
                id=int(row["id"]), building_id=int(row["building_id"]),
                room_number=str(row["room_number"]), room_type=row["room_type"],
                capacity=int(row["capacity"]),
            ))
        db.commit()

        print("Loading equipment...")
        equipment_df = pd.read_csv(os.path.join(DATA_DIR, "equipment.csv"))
        for _, row in equipment_df.iterrows():
            db.add(models.Equipment(
                id=int(row["id"]), building_id=int(row["building_id"]),
                room_number=None if pd.isna(row["room_number"]) else str(row["room_number"]),
                equipment_type=row["equipment_type"], install_year=int(row["install_year"]),
                last_service_date=pd.to_datetime(row["last_service_date"]),
                health_score=float(row["health_score"]), previous_failures=int(row["previous_failures"]),
            ))
        db.commit()

        print("Loading complaints (running NLP pipeline on each one)...")
        from nlp.pipeline import analyze_complaint
        complaints_df = pd.read_csv(os.path.join(DATA_DIR, "complaints.csv"))
        analyzed_texts = []
        parsed_rows = []
        for _, row in complaints_df.iterrows():
            nlp_result = analyze_complaint(row["raw_text"])
            parsed_rows.append((row, nlp_result))
            analyzed_texts.append(row["raw_text"])

        # Cluster all complaints together so related ones share a cluster_id.
        from nlp.clustering import cluster_complaints
        cluster_ids = cluster_complaints(analyzed_texts)

        for (row, nlp_result), cluster_id in zip(parsed_rows, cluster_ids):
            db.add(models.Complaint(
                id=int(row["id"]),
                raw_text=row["raw_text"],
                building=nlp_result["building"] or row["building"],
                room=nlp_result["room"] or str(row["room"]),
                equipment=nlp_result["equipment"],
                category=nlp_result["category"],
                problem=nlp_result["problem"],
                severity=nlp_result["severity"],
                urgency=nlp_result["urgency"],
                cluster_id=int(cluster_id),
                reporter_role=row["reporter_role"],
                status=row["status"],
                created_at=pd.to_datetime(row["created_at"]),
            ))
        db.commit()

        print("Loading telemetry (this is the largest table, please wait)...")
        telemetry_df = pd.read_csv(os.path.join(DATA_DIR, "telemetry.csv"))
        batch = []
        for _, row in telemetry_df.iterrows():
            batch.append(models.Telemetry(
                id=int(row["id"]), building_id=int(row["building_id"]),
                timestamp=pd.to_datetime(row["timestamp"]),
                temperature_c=float(row["temperature_c"]), electricity_kw=float(row["electricity_kw"]),
                water_flow_lpm=float(row["water_flow_lpm"]), occupancy=int(row["occupancy"]),
                wifi_users=int(row["wifi_users"]), hvac_on=bool(row["hvac_on"]),
            ))
            if len(batch) >= 500:
                db.bulk_save_objects(batch)
                db.commit()
                batch = []
        if batch:
            db.bulk_save_objects(batch)
            db.commit()

        print("Database seeded successfully.")
    finally:
        db.close()


if __name__ == "__main__":
    seed_database()
