"""
Trains and saves the ML models (anomaly detection + electricity forecasting)
used by the prediction API. Run this after scripts/generate_data.py.

Run with: python scripts/train.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ml.train_models import train_and_save_all  # noqa: E402

if __name__ == "__main__":
    train_and_save_all()
