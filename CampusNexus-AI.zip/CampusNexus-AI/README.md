# CampusNexus AI
### NLP-Powered Predictive Campus Digital Twin

A software-only AI/ML system that turns natural-language complaints and
simulated IoT telemetry into a live, explainable digital twin of a college
campus — complete with predictive risk scoring, a What-If simulator, and a
data-grounded AI assistant. No physical hardware, and no paid API key,
required.

---

## 1. Problem Statement

Campus facilities teams deal with scattered complaints (email, paper,
word-of-mouth) and no unified view of building health. Small issues (a
noisy AC, a slow drip) often go unnoticed until they become expensive
failures — a burst pipe, an electrical overload, a total HVAC breakdown.
There's no single place that connects *what people are reporting* with
*what the building's sensors are actually seeing*.

## 2. Solution

CampusNexus AI ingests free-text complaints, understands them with NLP
(entities, category, severity, urgency), finds related historical reports,
and cross-references them against simulated building telemetry
(temperature, electricity, water flow, occupancy, Wi-Fi). An explainable
risk engine turns all of that into HVAC / water / electricity risk scores
— each with a human-readable evidence list, not a black-box number — plus
concrete recommended actions. A What-If simulator lets administrators test
interventions before committing to them, and a natural-language assistant
answers operational questions using live data.

## 3. Features

- Natural-language complaint intake with full NLP analysis (entities,
  category, severity, urgency)
- Duplicate/related-complaint detection via semantic similarity + clustering
- Synthetic campus digital twin (6 buildings, telemetry every hour)
- Explainable HVAC failure, water leak, and electricity overload risk
  scoring — every score comes with an evidence list and a recommended action
- What-If simulator (occupancy, AC usage/temperature, non-critical
  equipment, water usage → before/after electricity & risk)
- AI Campus Assistant that answers from real data (works with **zero**
  API key; optionally upgradeable to a real LLM)
- Full REST API + React dashboard styled as an operations command center
- 100% synthetic/demo data — runs anywhere, no IoT hardware needed

## 4. Architecture

See [`docs/architecture.md`](docs/architecture.md) for a full diagram and
explanation of the request flows and design decisions (including why the
risk engine is rule-based rather than a black-box model).

## 5. NLP Pipeline

`nlp/` implements: text cleaning → tokenization → normalization → entity
extraction (building/room/equipment via regex + dictionaries) →
classification (category/severity/urgency via explainable keyword
scoring) → TF-IDF semantic similarity → connected-components clustering.

An optional upgrade path exists for `spaCy` (tokenization) and
`sentence-transformers` (semantic embeddings) — both are auto-detected and
used if installed and downloadable; otherwise the app **automatically
falls back** to the dependency-free regex/TF-IDF path. You do not need to
install either to run the full demo.

## 6. ML Pipeline

`ml/` implements:
- **Isolation Forest** (scikit-learn) for general telemetry anomaly detection
- **Linear Regression** (scikit-learn) for lightweight electricity load forecasting
- Explainable, weighted-rule scorers for HVAC failure risk, water anomaly
  risk, and electricity overload risk (each returns a 0-100 score **and**
  a list of evidence strings)

Models are trained once via `scripts/train.py` and saved to `/models`
with `joblib`.

## 7. Digital Twin

6 synthetic buildings (Block A/B/C, Library, Laboratory Block,
Administration Block), each with hourly telemetry: temperature,
electricity, water flow, occupancy, Wi-Fi users, HVAC state. Three
intentional anomalies are seeded into the data so the risk engine has
something real to catch — see [`data/README.md`](data/README.md).

## 8. What-If Simulator

Transparent, tunable formulas (see `backend/api/simulation.py`) convert
occupancy / AC usage / AC temperature / non-critical equipment into an
electricity estimate and risk score, so you can see the *before* and
*after* impact of a proposed change instantly.

## 9. Technology Stack

**Backend:** Python 3.11+, FastAPI, Uvicorn, Pydantic, Pandas, NumPy,
scikit-learn, joblib, SQLAlchemy, SQLite
**Frontend:** React, Vite, Tailwind CSS, Recharts, Axios, React Router
**NLP:** TF-IDF/cosine similarity (default), optional spaCy /
sentence-transformers
**LLM (optional):** OpenAI or Anthropic API, only used if `LLM_API_KEY` is set

## 10. Project Structure

```
CampusNexus-AI/
├── backend/            FastAPI app: api/, services/, models, schemas, config
├── nlp/                NLP pipeline (preprocessing, entities, classifier, similarity, clustering)
├── ml/                 ML models & explainable risk scoring
├── data/                Synthetic CSV datasets (generated)
├── scripts/            generate_data.py, seed.py, train.py
├── models/              Saved ML models (joblib) — generated
├── frontend/            React + Vite + Tailwind dashboard
├── tests/               pytest suite (NLP, risk engine, API)
├── docs/                architecture.md, api.md, demo.md, screenshots.md
├── requirements.txt
├── package.json          root convenience scripts
├── docker-compose.yml    optional
└── README.md
```

## 11. Installation (Windows, macOS, Linux)

### Prerequisites
- Python 3.11+
- Node.js 18+ and npm

### 12. Backend Setup
```bash
python -m venv venv

# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

pip install -r requirements.txt
```

### 13. Frontend Setup
```bash
cd frontend
npm install
cd ..
```

### 14. Database Setup
The database is created and seeded **automatically** the first time you
start the backend. To do it manually instead (recommended the first time,
so you can see the generated data counts):
```bash
python scripts\generate_data.py
python scripts\seed.py
```
(macOS/Linux: `python scripts/generate_data.py` and `python scripts/seed.py`)

### 15. Model Setup
```bash
python scripts\train.py
```
(macOS/Linux: `python scripts/train.py`)

This trains and saves the Isolation Forest and electricity regression
models to `/models`. The risk engine itself (HVAC/water/electricity
scoring) does **not** require this step — it uses the explainable rule
scorers directly — but running it lets `ml/anomaly_detection.py` and
`ml/electricity_prediction.py` be used interactively if you extend the
project.

### 16. Running Instructions

**Terminal 1 — backend:**
```bash
uvicorn backend.main:app --reload
```
API available at `http://localhost:8000`, interactive docs at
`http://localhost:8000/docs`.

**Terminal 2 — frontend:**
```bash
cd frontend
npm run dev
```
Open the URL Vite prints (usually `http://localhost:5173`).

## 17. API Documentation

See [`docs/api.md`](docs/api.md) for every endpoint with example
requests/responses.

## 18. Demo Instructions

See [`docs/demo.md`](docs/demo.md) for the full step-by-step walkthrough
(matches the scenario this project was designed around: submit a Block B
AC complaint → see NLP analysis → see similar past complaints → see HVAC
risk score with evidence → run the What-If simulator → ask the assistant).

## 19. Screenshots

See [`docs/screenshots.md`](docs/screenshots.md) — add your own after
running the app locally.

## 20. Environment Variables

Copy `.env.example` to `.env` if you want to change anything (all
optional — the app works fully without a `.env` file):
```
LLM_API_KEY=
LLM_PROVIDER=openai        # or "anthropic"
DATABASE_URL=sqlite:///./campusnexus.db
```

## 21. Future Improvements

- Real IoT sensor ingestion (MQTT/HTTP webhook) instead of synthetic data
- Persist trained ML models with versioning + scheduled retraining
- Role-based auth for the facilities team vs. general reporters
- Push notifications for HIGH risk events
- Multi-campus / multi-tenant support

## 22. Limitations

- All telemetry and complaint data is **synthetic**, generated to be
  realistic for a demo — it is not connected to real sensors.
- The NLP entity/category extraction is a transparent, explainable
  rule+keyword system by design (not a trained deep-learning model); it
  covers the vocabulary in this project's demo well but is not a general
  production NLU system.
- The campus map is rendered as a risk-colored building grid rather than a
  literal Leaflet tile map, since the synthetic buildings share
  closely-clustered placeholder coordinates with no real GPS meaning for
  an indoor facilities twin.
- The optional LLM assistant mode requires your own API key and internet
  access; without one, the app uses the local deterministic assistant.

## 23. Team Contribution

_Add your team members and their roles here, e.g.:_
- **Name** — Backend & ML (FastAPI, risk engine, ML models)
- **Name** — NLP pipeline (entity extraction, classification, similarity)
- **Name** — Frontend (React dashboard, simulator, assistant UI)
- **Name** — Data generation, testing, documentation

## 24. License

MIT — see [`LICENSE`](LICENSE).

---

## Quick Start (TL;DR)

```bash
git clone <your-repo-url>
cd CampusNexus-AI

python -m venv venv
venv\Scripts\activate            # Windows
# source venv/bin/activate       # macOS/Linux
pip install -r requirements.txt
python scripts\seed.py           # generates data + seeds DB (Windows)
# python scripts/seed.py         # macOS/Linux
python scripts\train.py          # or scripts/train.py
uvicorn backend.main:app --reload

# in a second terminal:
cd frontend
npm install
npm run dev
```

## Git Commands
```bash
git init
git add .
git commit -m "Initial CampusNexus AI implementation"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

## Troubleshooting

| Problem | Fix |
|---|---|
| `ModuleNotFoundError: No module named 'backend'` | Run commands from the project root (not inside `backend/`), and make sure your venv is activated. |
| Frontend shows "Could not reach the backend" | Confirm `uvicorn backend.main:app --reload` is running on port 8000, and that you started it before/alongside the frontend. |
| Empty dashboard / no risk data | Run `python scripts/seed.py` manually, then restart the backend. |
| `sentence-transformers`/`spacy` import errors | These are optional — leave them out of your installed packages entirely; the app automatically uses the TF-IDF/regex fallback. |
| Port 8000 or 5173 already in use | Stop the other process, or run `uvicorn backend.main:app --reload --port 8001` (and update `VITE_API_BASE_URL` / the Vite proxy target to match). |
| `pip install` fails on Windows for a specific package | Upgrade pip first: `python -m pip install --upgrade pip`, then retry. |

## Example API Request

```bash
curl -X POST http://localhost:8000/api/analyze-complaint \
  -H "Content-Type: application/json" \
  -d "{\"text\": \"The AC in Block B room 304 is making strange noise and the room is very hot.\"}"
```

Expected output:
```json
{
  "building": "Block B",
  "room": "304",
  "equipment": "AC",
  "category": "HVAC",
  "problem": "possible AC/HVAC failure (unusual noise reported)",
  "severity": "HIGH",
  "urgency": "MEDIUM",
  "cluster_id": 3,
  "similar_complaints": [ ... ]
}
```
