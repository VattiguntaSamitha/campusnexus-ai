# Data Directory

This folder holds the synthetic demo dataset used by CampusNexus AI. It is
generated automatically — you do not need to create these files by hand.

Run:
```
python scripts/generate_data.py
```

This produces:

| File | Description |
|---|---|
| `campus_buildings.csv` | 6 campus buildings with coordinates |
| `rooms.csv` | ~50 rooms distributed across buildings |
| `equipment.csv` | ~40 equipment records (AC, pumps, panels, etc.) with health scores and install years |
| `complaints.csv` | ~500 realistic natural-language complaints with timestamps |
| `telemetry.csv` | ~5,000 hourly sensor readings (temperature, electricity, water flow, occupancy, Wi-Fi users) |

The generator seeds three intentional anomalies so the risk engine has
something real to detect during a demo:

1. **Block B — HVAC risk**: older, lower-health AC/chiller units plus a
   spike in HVAC-related complaints.
2. **Block C — water leakage**: elevated water flow during night-time
   hours over the last few days (not explained by occupancy).
3. **Block B — electricity overload**: sustained high power draw over the
   last few days.

After generating the CSVs, load them into the SQLite database with:
```
python scripts/seed.py
```
