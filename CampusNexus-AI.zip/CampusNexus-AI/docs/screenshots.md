# Screenshots

Add screenshots here after running the app locally. Suggested shots for a
hackathon README/submission:

1. **Dashboard** — full campus view with health score and building cards.
2. **Complaint submission + NLP analysis result** (the Block B AC example).
3. **Predictions page** — HVAC risk score with evidence list for Block B.
4. **What-If Simulator** — before/after comparison.
5. **AI Assistant** — a question and its data-grounded answer.

To capture and embed:
```markdown
![Dashboard](./screenshots/dashboard.png)
```
Create a `docs/screenshots/` folder and drop your `.png` files there, then
reference them from this file and from the main `README.md`.
