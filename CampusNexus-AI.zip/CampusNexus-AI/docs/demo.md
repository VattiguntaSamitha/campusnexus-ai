# Demo Walkthrough

This is the recommended order to demo CampusNexus AI, matching the
scenario the project was designed around.

## 1. Start both servers
```
# Terminal 1
uvicorn backend.main:app --reload

# Terminal 2
cd frontend && npm run dev
```
Open the frontend URL Vite prints (usually `http://localhost:5173`).

## 2. Open the Dashboard
Point out:
- Campus Health Score at the top.
- Block B (and/or Block C) showing an elevated risk level — this comes
  from the intentional anomalies seeded into the synthetic data.
- Live per-building electricity, water, occupancy, and temperature.

## 3. Submit a complaint
Go to the Complaints page and submit:
> "The AC in Block B room 304 has been making strange noises and the room is very hot."

Show the NLP analysis result:
- Building: Block B
- Room: 304
- Category: HVAC
- Severity: HIGH
- Urgency: HIGH (or MEDIUM depending on exact wording)

## 4. Show similar historical complaints
The analysis response includes semantically related past complaints about
Block B's AC — demonstrating duplicate/related-issue detection.

## 5. Open the Predictions page
Show the HVAC risk score for Block B, with its evidence list (equipment
age, health score, complaint frequency, temperature delta) and the
recommended action.

## 6. Open the What-If Simulator
Select Block B, then:
- Change AC temperature from 20°C → 24°C
- Turn non-critical equipment OFF

Show the before/after electricity and risk comparison, and the
recommended intervention text.

## 7. Open the AI Assistant
Ask:
- "What are the biggest problems today?"
- "Which building has the highest risk?"
- "Why is Block B electricity high?"
- "Show HVAC problems."

Each answer is generated from the live database — not hardcoded.

## Resetting the demo
To regenerate fresh synthetic data (new random anomalies each time) and
reseed the database:
```
python scripts/generate_data.py
python scripts/seed.py
python scripts/train.py
```
