# Architecture

## Overview

CampusNexus AI is a software-only digital twin of a college campus. It has
three logical layers:

```
┌─────────────────────────────────────────────────────────────┐
│  Frontend (React + Vite + Tailwind + Recharts)               │
│  Dashboard | Complaints | Predictions | Simulator | Assistant│
└───────────────────────────┬───────────────────────────────────┘
                             │ REST (JSON over HTTP)
┌───────────────────────────▼───────────────────────────────────┐
│  Backend (FastAPI)                                            │
│  api/  -> routers (complaints, dashboard, predictions,         │
│           simulation, assistant)                               │
│  services/ -> business logic, orchestrates nlp/ + ml/ + DB     │
│  models.py / schemas.py / database.py / config.py              │
└───────────────────────────┬───────────────────────────────────┘
                             │
        ┌────────────────────┼─────────────────────┐
        ▼                    ▼                      ▼
┌───────────────┐   ┌────────────────┐    ┌──────────────────┐
│ nlp/           │   │ ml/             │    │ SQLite database   │
│ preprocessing  │   │ anomaly_detect  │    │ (buildings, rooms,│
│ entity_extract │   │ electricity     │    │ equipment,        │
│ classifier     │   │ equipment_fail  │    │ complaints,       │
│ similarity     │   │ water_anomaly   │    │ telemetry,        │
│ clustering     │   │ risk_engine     │    │ predictions,      │
│ pipeline       │   │ train_models    │    │ recommendations)  │
└───────────────┘   └────────────────┘    └──────────────────┘
```

## Request flow: submitting a complaint

1. Frontend `ComplaintForm` POSTs raw text to `/api/analyze-complaint` for a
   live preview, then `/api/complaints` to save it.
2. `backend/api/complaints.py` calls `backend/services/complaint_service.py`.
3. `complaint_service` calls `nlp/pipeline.py`, which runs:
   - `preprocessing.py` (clean + tokenize)
   - `entity_extractor.py` (building, room, equipment)
   - `classifier.py` (category, severity, urgency)
4. `complaint_service` then compares the new text against recent complaints
   in the same category using `nlp/similarity.py` (TF-IDF cosine
   similarity, or sentence-transformers if installed), and assigns a
   cluster id via `nlp/clustering.py`'s connected-components approach.
5. The fully-analyzed complaint is saved to the `complaints` table.

## Request flow: computing risk

1. Frontend requests `/api/risks` or `/api/predictions`.
2. `backend/services/risk_engine.py` loads the building's latest telemetry
   and a 14-day historical baseline (`telemetry_service.py`), plus recent
   complaint counts and equipment health (`complaint_service.py`,
   `models.Equipment`).
3. It calls the pure, explainable scoring functions in `ml/equipment_failure.py`,
   `ml/water_anomaly.py`, and `ml/electricity_prediction.py` — each of
   which returns a `score` (0-100) and a list of human-readable `evidence`
   strings.
4. `ml/risk_engine.py` converts the score into a LOW/MEDIUM/HIGH label and a
   recommended action string.
5. `/api/predictions` additionally persists a snapshot to the `predictions`
   table and calls `recommendation_engine.py` to generate/update
   recommendations.

## Why deterministic/explainable models instead of deep learning?

The project's requirement is that **every prediction must be explainable**
and reproducible — not a random number generated on each request. A
transparent, weighted rule-based scorer (with only a handful of real,
well-understood input signals) is:

- Easy for a beginner to read, debug, and extend.
- Fully auditable: every point added to a risk score has a matching
  evidence string.
- Fast: no GPU, no heavy training step required to get a working demo.

Where a real trained model *is* the right tool (detecting statistically
unusual telemetry patterns, forecasting electricity load from multiple
correlated inputs), the project uses `scikit-learn` (`IsolationForest`,
`LinearRegression`) — trained once via `scripts/train.py` and saved to
`/models` with `joblib`.

## NLP fallback strategy

Both `nlp/preprocessing.py` (tokenization) and `nlp/similarity.py`
(semantic matching) try to use a heavier model first
(`spaCy`/`sentence-transformers`) and **automatically fall back** to a
dependency-free approach (regex tokenizer / TF-IDF) if the package isn't
installed or a model can't be downloaded. This means the app always works,
even fully offline.
