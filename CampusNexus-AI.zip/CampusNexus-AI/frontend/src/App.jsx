import React from "react";
import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Dashboard from "./pages/Dashboard";
import Complaints from "./pages/Complaints";
import Predictions from "./pages/Predictions";
import Simulator from "./pages/Simulator";
import Assistant from "./pages/Assistant";

export default function App() {
  return (
    <div className="min-h-screen bg-[#0b1220]">
      <Navbar />
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/complaints" element={<Complaints />} />
        <Route path="/predictions" element={<Predictions />} />
        <Route path="/simulator" element={<Simulator />} />
        <Route path="/assistant" element={<Assistant />} />
      </Routes>
    </div>
  );
}
