import axios from "axios";

// In dev, Vite proxies "/api" to the FastAPI backend (see vite.config.js).
// In production, set VITE_API_BASE_URL to your deployed backend URL.
const baseURL = import.meta.env.VITE_API_BASE_URL || "/api";

const api = axios.create({ baseURL, timeout: 15000 });

export const getDashboard = () => api.get("/dashboard").then((r) => r.data);
export const getBuildings = () => api.get("/buildings").then((r) => r.data);
export const getTelemetry = (building, hours = 48) =>
  api.get("/telemetry", { params: { building, hours } }).then((r) => r.data);
export const getEquipment = (building) =>
  api.get("/equipment", { params: { building } }).then((r) => r.data);

export const getRisks = (building) =>
  api.get("/risks", { params: { building } }).then((r) => r.data);
export const getPredictions = () => api.get("/predictions").then((r) => r.data);
export const getRecommendations = () => api.get("/recommendations").then((r) => r.data);

export const getComplaints = (params = {}) =>
  api.get("/complaints", { params }).then((r) => r.data);
export const submitComplaint = (text, reporter_role = "student") =>
  api.post("/complaints", { text, reporter_role }).then((r) => r.data);
export const analyzeComplaint = (text) =>
  api.post("/analyze-complaint", { text }).then((r) => r.data);

export const simulate = (payload) => api.post("/simulate", payload).then((r) => r.data);

export const askAssistant = (question) =>
  api.post("/assistant", { question }).then((r) => r.data);

export default api;
