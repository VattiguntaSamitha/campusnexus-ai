import React, { useEffect, useState } from "react";
import { getPredictions, getRecommendations } from "../api";
import PredictionPanel from "../components/PredictionPanel";
import RecommendationCard from "../components/RecommendationCard";

export default function Predictions() {
  const [risks, setRisks] = useState([]);
  const [recommendations, setRecommendations] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setLoading(true);
    try {
      const [riskData, recData] = await Promise.all([getPredictions(), getRecommendations()]);
      setRisks(riskData);
      setRecommendations(recData);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-7xl space-y-8 p-4 sm:p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Predictive Risk Analysis</h1>
          <p className="text-sm text-slate-400">Explainable HVAC, water, and electricity risk scores computed from live campus data.</p>
        </div>
        <button
          onClick={load}
          className="rounded-lg border border-slate-700 px-3 py-1.5 text-sm text-slate-200 hover:bg-slate-800"
        >
          Refresh
        </button>
      </div>

      <PredictionPanel risks={risks} loading={loading} />

      <div>
        <p className="mb-2 text-sm font-semibold text-white">Recommendations</p>
        {recommendations.length === 0 ? (
          <p className="text-sm text-slate-400">No active recommendations — all systems within normal range.</p>
        ) : (
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {recommendations.map((r) => (
              <RecommendationCard key={r.id} recommendation={r} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
