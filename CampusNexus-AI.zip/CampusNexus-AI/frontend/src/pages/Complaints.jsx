import React, { useEffect, useState } from "react";
import { getComplaints } from "../api";
import ComplaintForm from "../components/ComplaintForm";
import ComplaintList from "../components/ComplaintList";

export default function Complaints() {
  const [complaints, setComplaints] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setLoading(true);
    try {
      const data = await getComplaints({ limit: 30 });
      setComplaints(data);
    } finally {
      setLoading(false);
    }
  }

  function handleSubmitted(newComplaint) {
    setComplaints((prev) => [newComplaint, ...prev]);
  }

  return (
    <div className="mx-auto max-w-5xl space-y-6 p-4 sm:p-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Complaints</h1>
        <p className="text-sm text-slate-400">
          Submit natural-language complaints. CampusNexus AI extracts structured details and finds related past issues automatically.
        </p>
      </div>

      <ComplaintForm onSubmitted={handleSubmitted} />

      <div>
        <p className="mb-2 text-sm font-semibold text-white">Recent Complaints</p>
        {loading ? (
          <p className="text-sm text-slate-400">Loading...</p>
        ) : (
          <ComplaintList complaints={complaints} />
        )}
      </div>
    </div>
  );
}
