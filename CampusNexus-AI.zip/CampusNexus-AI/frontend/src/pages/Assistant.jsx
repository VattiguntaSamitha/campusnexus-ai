import React, { useState } from "react";
import { askAssistant } from "../api";

const SUGGESTIONS = [
  "What are the biggest problems today?",
  "Which building has the highest risk?",
  "Why is Block B electricity high?",
  "Are there any possible water leaks?",
  "Show HVAC problems.",
  "What should maintenance inspect first?",
];

export default function Assistant() {
  const [messages, setMessages] = useState([
    { role: "assistant", text: "Hi! Ask me about campus risk, complaints, or maintenance priorities. I answer using live data from the digital twin.", source: "local" },
  ]);
  const [question, setQuestion] = useState("");
  const [loading, setLoading] = useState(false);

  async function ask(q) {
    const finalQuestion = q ?? question;
    if (!finalQuestion.trim()) return;
    setMessages((prev) => [...prev, { role: "user", text: finalQuestion }]);
    setQuestion("");
    setLoading(true);
    try {
      const res = await askAssistant(finalQuestion);
      setMessages((prev) => [...prev, { role: "assistant", text: res.answer, source: res.source }]);
    } catch (err) {
      setMessages((prev) => [...prev, { role: "assistant", text: "Sorry, I couldn't reach the backend just now.", source: "local" }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto flex max-w-3xl flex-col space-y-4 p-4 sm:p-6">
      <div>
        <h1 className="text-2xl font-bold text-white">AI Campus Assistant</h1>
        <p className="text-sm text-slate-400">
          Grounded in live campus data — never hardcoded. Uses a local deterministic assistant unless an LLM API key is configured.
        </p>
      </div>

      <div className="flex flex-wrap gap-2">
        {SUGGESTIONS.map((s) => (
          <button
            key={s}
            onClick={() => ask(s)}
            className="rounded-full border border-slate-700 px-3 py-1 text-xs text-slate-300 hover:bg-slate-800"
          >
            {s}
          </button>
        ))}
      </div>

      <div className="card flex-1 space-y-3 overflow-y-auto p-4" style={{ minHeight: "20rem" }}>
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[85%] rounded-2xl px-4 py-2 text-sm ${
                m.role === "user" ? "bg-cyan-500 text-slate-900" : "bg-slate-800 text-slate-100"
              }`}
            >
              {m.text}
              {m.role === "assistant" && (
                <p className="mt-1 text-[10px] uppercase tracking-wide text-slate-400">
                  {m.source === "llm" ? "LLM-assisted" : "Local assistant"}
                </p>
              )}
            </div>
          </div>
        ))}
        {loading && <p className="text-xs text-slate-500">Thinking...</p>}
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          ask();
        }}
        className="flex gap-2"
      >
        <input
          className="flex-1 rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-slate-100 outline-none focus:border-cyan-500"
          placeholder="Ask about campus status..."
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
        />
        <button
          type="submit"
          disabled={loading}
          className="rounded-lg bg-cyan-500 px-4 py-2 text-sm font-semibold text-slate-900 hover:bg-cyan-400 disabled:opacity-50"
        >
          Ask
        </button>
      </form>
    </div>
  );
}
