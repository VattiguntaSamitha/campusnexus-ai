import React, { useEffect, useState } from "react";
import { getDashboard, getTelemetry } from "../api";
import StatCard from "../components/StatCard";
import CampusMap from "../components/CampusMap";
import TelemetryChart from "../components/TelemetryChart";

export default function Dashboard() {
  const [dashboard, setDashboard] = useState(null);
  const [selected, setSelected] = useState(null);
  const [telemetry, setTelemetry] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    loadDashboard();
    const interval = setInterval(loadDashboard, 30000); // live-ish refresh every 30s
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (selected) {
      getTelemetry(selected, 48).then(setTelemetry).catch(() => setTelemetry([]));
    }
  }, [selected]);

  async function loadDashboard() {
    try {
      const data = await getDashboard();
      setDashboard(data);
      if (!selected && data.buildings.length > 0) {
        setSelected(data.buildings[0].building);
      }
      setError("");
    } catch (err) {
      setError("Could not reach the backend. Is `uvicorn backend.main:app --reload` running?");
    }
  }

  if (error) {
    return <div className="mx-auto max-w-7xl p-6 text-red-400">{error}</div>;
  }
  if (!dashboard) {
    return <div className="mx-auto max-w-7xl p-6 text-slate-400">Loading campus digital twin...</div>;
  }

  return (
    <div className="mx-auto max-w-7xl space-y-6 p-4 sm:p-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Live Campus Status</h1>
        <p className="text-sm text-slate-400">AI operations command center — updated in real time from live telemetry.</p>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-7">
        <StatCard label="Campus Health" value={`${dashboard.campus_health_score}`} accent="cyan" />
        <StatCard label="Buildings" value={dashboard.total_buildings} accent="cyan" />
        <StatCard label="Active Alerts" value={dashboard.active_alerts} accent="amber" />
        <StatCard label="High-Risk Issues" value={dashboard.high_risk_issues} accent="red" />
        <StatCard label="Electricity" value={`${dashboard.total_electricity_kw} kW`} accent="cyan" />
        <StatCard label="Water" value={`${dashboard.total_water_flow_lpm} L/m`} accent="cyan" />
        <StatCard label="Occupancy" value={dashboard.total_occupancy} accent="emerald" />
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="lg:col-span-1">
          <CampusMap buildings={dashboard.buildings} selected={selected} onSelect={setSelected} />
        </div>
        <div className="lg:col-span-2">
          <TelemetryChart data={telemetry} metric="electricity_kw" title={`${selected || ""} — Electricity (48h)`} />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <TelemetryChart data={telemetry} metric="temperature_c" title={`${selected || ""} — Temperature (48h)`} />
        <TelemetryChart data={telemetry} metric="water_flow_lpm" title={`${selected || ""} — Water Flow (48h)`} />
      </div>

      <div>
        <p className="mb-2 text-sm font-semibold text-white">Building Details</p>
        <div className="overflow-x-auto card">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-slate-800 text-xs uppercase tracking-wide text-slate-500">
              <tr>
                <th className="p-3">Building</th>
                <th className="p-3">Electricity</th>
                <th className="p-3">Water</th>
                <th className="p-3">Occupancy</th>
                <th className="p-3">Temp</th>
                <th className="p-3">Network</th>
                <th className="p-3">Risk</th>
              </tr>
            </thead>
            <tbody>
              {dashboard.buildings.map((b) => (
                <tr key={b.building} className="border-b border-slate-800/60 last:border-0">
                  <td className="p-3 font-medium text-slate-100">{b.building}</td>
                  <td className="p-3 text-slate-300">{b.electricity_kw} kW</td>
                  <td className="p-3 text-slate-300">{b.water_flow_lpm} L/m</td>
                  <td className="p-3 text-slate-300">{b.occupancy}</td>
                  <td className="p-3 text-slate-300">{b.temperature_c}°C</td>
                  <td className="p-3 text-slate-300">{b.wifi_users} users</td>
                  <td className="p-3">
                    <span className={`badge-${b.risk_level} rounded-full px-2 py-0.5 text-xs font-bold`}>
                      {b.risk_level}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
