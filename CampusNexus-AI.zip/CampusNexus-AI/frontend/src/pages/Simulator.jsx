import React, { useEffect, useState } from "react";
import { getBuildings } from "../api";
import WhatIfSimulator from "../components/WhatIfSimulator";

export default function Simulator() {
  const [buildings, setBuildings] = useState([]);

  useEffect(() => {
    getBuildings().then(setBuildings).catch(() => setBuildings([]));
  }, []);

  return (
    <div className="mx-auto max-w-5xl space-y-6 p-4 sm:p-6">
      <div>
        <h1 className="text-2xl font-bold text-white">What-If Simulator</h1>
        <p className="text-sm text-slate-400">
          Model the effect of operational changes before making them — see electricity and risk impact instantly.
        </p>
      </div>

      {buildings.length === 0 ? (
        <p className="text-sm text-slate-400">Loading buildings...</p>
      ) : (
        <WhatIfSimulator buildings={buildings} />
      )}
    </div>
  );
}
