import React from "react";

export default function RiskCard({ risk }) {
  return (
    <div className="card p-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-semibold text-white">{risk.building}</p>
          <p className="text-xs text-slate-400">{risk.risk_type} risk</p>
        </div>
        <span className={`badge-${risk.risk_level} rounded-full px-2.5 py-1 text-xs font-bold`}>
          {risk.risk_level}
        </span>
      </div>

      <div className="mt-3">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <span>Risk score</span>
          <span className={`risk-${risk.risk_level} font-semibold`}>{Math.round(risk.risk_score)}%</span>
        </div>
        <div className="mt-1 h-2 w-full overflow-hidden rounded-full bg-slate-800">
          <div
            className={`h-full rounded-full ${
              risk.risk_level === "HIGH" ? "bg-red-500" : risk.risk_level === "MEDIUM" ? "bg-amber-400" : "bg-emerald-400"
            }`}
            style={{ width: `${Math.min(risk.risk_score, 100)}%` }}
          />
        </div>
      </div>

      {risk.evidence?.length > 0 && (
        <ul className="mt-3 space-y-1 text-xs text-slate-400">
          {risk.evidence.map((e, i) => (
            <li key={i} className="flex gap-1.5">
              <span className="text-slate-600">•</span>
              <span>{e}</span>
            </li>
          ))}
        </ul>
      )}

      {risk.recommended_action && (
        <p className="mt-3 rounded-lg bg-slate-800/60 p-2 text-xs text-slate-300">
          <span className="font-semibold text-cyan-300">Recommended: </span>
          {risk.recommended_action}
        </p>
      )}
    </div>
  );
}
