import React, { useState } from "react";
import { simulate } from "../api";

export default function WhatIfSimulator({ buildings = [] }) {
  const [building, setBuilding] = useState(buildings[0]?.name || buildings[0]?.building || "");
  const [occupancy, setOccupancy] = useState(100);
  const [acUsage, setAcUsage] = useState(70);
  const [acTemp, setAcTemp] = useState(20);
  const [nonCritical, setNonCritical] = useState(true);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function runSimulation() {
    if (!building) return;
    setLoading(true);
    setError("");
    try {
      const res = await simulate({
        building,
        occupancy: Number(occupancy),
        ac_usage_percent: Number(acUsage),
        ac_temperature_c: Number(acTemp),
        non_critical_equipment_on: nonCritical,
      });
      setResult(res);
    } catch (err) {
      setError(err?.response?.data?.detail || "Simulation failed.");
    } finally {
      setLoading(false);
    }
  }

  const buildingNames = buildings.map((b) => b.name || b.building);

  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
      <div className="card space-y-4 p-4">
        <p className="text-sm font-semibold text-white">What-If Simulator</p>

        <div>
          <label className="text-xs text-slate-400">Building</label>
          <select
            className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-900 px-2 py-1.5 text-sm text-slate-200"
            value={building}
            onChange={(e) => setBuilding(e.target.value)}
          >
            {buildingNames.map((name) => (
              <option key={name} value={name}>{name}</option>
            ))}
          </select>
        </div>

        <SliderField label={`Occupancy (${occupancy} people)`} min={0} max={300} value={occupancy} onChange={setOccupancy} />
        <SliderField label={`AC Usage (${acUsage}%)`} min={0} max={100} value={acUsage} onChange={setAcUsage} />
        <SliderField label={`AC Temperature (${acTemp}°C)`} min={16} max={30} value={acTemp} onChange={setAcTemp} />

        <label className="flex items-center gap-2 text-sm text-slate-300">
          <input type="checkbox" checked={nonCritical} onChange={(e) => setNonCritical(e.target.checked)} />
          Non-critical equipment ON
        </label>

        <button
          onClick={runSimulation}
          disabled={loading || !building}
          className="w-full rounded-lg bg-cyan-500 px-3 py-2 text-sm font-semibold text-slate-900 hover:bg-cyan-400 disabled:opacity-50"
        >
          {loading ? "Simulating..." : "Run Simulation"}
        </button>
        {error && <p className="text-sm text-red-400">{error}</p>}
      </div>

      <div className="card p-4">
        <p className="mb-3 text-sm font-semibold text-white">Result</p>
        {!result ? (
          <p className="text-sm text-slate-400">Adjust the controls and run a simulation to see before/after impact.</p>
        ) : (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <ResultBlock title="BEFORE" data={result.before} />
              <ResultBlock title="AFTER" data={result.after} highlight />
            </div>
            <div className="rounded-lg bg-slate-900/60 p-3 text-sm">
              <p className="text-slate-400">Electricity change:{" "}
                <span className={result.difference.electricity_kw <= 0 ? "text-emerald-400" : "text-red-400"}>
                  {result.difference.electricity_kw > 0 ? "+" : ""}{result.difference.electricity_kw} kW
                </span>
              </p>
              <p className="text-slate-400">Risk change:{" "}
                <span className={result.difference.risk_score <= 0 ? "text-emerald-400" : "text-red-400"}>
                  {result.difference.risk_score > 0 ? "+" : ""}{result.difference.risk_score}%
                </span>
              </p>
            </div>
            <p className="rounded-lg bg-slate-800/60 p-3 text-sm text-slate-200">
              {result.recommended_intervention}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

function SliderField({ label, min, max, value, onChange }) {
  return (
    <div>
      <label className="text-xs text-slate-400">{label}</label>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full accent-cyan-400"
      />
    </div>
  );
}

function ResultBlock({ title, data, highlight }) {
  return (
    <div className={`rounded-lg border p-3 ${highlight ? "border-cyan-500/40 bg-cyan-500/5" : "border-slate-700 bg-slate-900/40"}`}>
      <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">{title}</p>
      <p className="mt-1 text-xl font-bold text-white">{data.electricity_kw} kW</p>
      <p className={`risk-${data.risk_level} text-sm font-semibold`}>{data.risk_score}% ({data.risk_level})</p>
    </div>
  );
}
