import React from "react";
import {
  ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
} from "recharts";

const METRICS = {
  temperature_c: { label: "Temperature (°C)", color: "#fb923c" },
  electricity_kw: { label: "Electricity (kW)", color: "#22d3ee" },
  water_flow_lpm: { label: "Water Flow (L/min)", color: "#60a5fa" },
  occupancy: { label: "Occupancy", color: "#a78bfa" },
};

export default function TelemetryChart({ data = [], metric = "electricity_kw", title }) {
  const config = METRICS[metric] || METRICS.electricity_kw;
  const chartData = data.map((d) => ({
    ...d,
    time: new Date(d.timestamp).toLocaleString([], { month: "short", day: "numeric", hour: "2-digit" }),
  }));

  return (
    <div className="card p-4">
      <p className="mb-3 text-sm font-semibold text-white">{title || config.label}</p>
      <div className="h-64 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chartData} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1f2b45" />
            <XAxis dataKey="time" tick={{ fontSize: 10, fill: "#64748b" }} minTickGap={30} />
            <YAxis tick={{ fontSize: 10, fill: "#64748b" }} />
            <Tooltip
              contentStyle={{ background: "#131c31", border: "1px solid #1f2b45", borderRadius: 8, fontSize: 12 }}
            />
            <Legend wrapperStyle={{ fontSize: 12 }} />
            <Line type="monotone" dataKey={metric} name={config.label} stroke={config.color} dot={false} strokeWidth={2} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
