import React from "react";
import RiskCard from "./RiskCard";

export default function PredictionPanel({ risks = [], loading }) {
  if (loading) {
    return <div className="card p-4 text-sm text-slate-400">Running prediction models...</div>;
  }
  if (risks.length === 0) {
    return <div className="card p-4 text-sm text-slate-400">No predictions available yet.</div>;
  }

  const grouped = risks.reduce((acc, r) => {
    acc[r.risk_type] = acc[r.risk_type] || [];
    acc[r.risk_type].push(r);
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      {Object.entries(grouped).map(([type, items]) => (
        <div key={type}>
          <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">{type} Risk</p>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {items
              .sort((a, b) => b.risk_score - a.risk_score)
              .map((r, i) => (
                <RiskCard key={`${r.building}-${type}-${i}`} risk={r} />
              ))}
          </div>
        </div>
      ))}
    </div>
  );
}
