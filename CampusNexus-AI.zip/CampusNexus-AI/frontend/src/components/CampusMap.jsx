import React from "react";

// NOTE: this project's buildings share synthetic, closely-clustered
// coordinates (there's no real campus GPS data), so a literal Leaflet
// tile map wouldn't convey anything useful. Instead this renders a
// clean, risk-colored building grid - simpler, and arguably more readable
// for an indoor-facilities digital twin. Swap in react-leaflet here if you
// have real building coordinates.
const riskColor = {
  HIGH: "border-red-500/60 bg-red-500/10",
  MEDIUM: "border-amber-400/60 bg-amber-400/10",
  LOW: "border-emerald-400/60 bg-emerald-400/10",
};

const riskDot = {
  HIGH: "bg-red-500",
  MEDIUM: "bg-amber-400",
  LOW: "bg-emerald-400",
};

export default function CampusMap({ buildings = [], onSelect, selected }) {
  return (
    <div className="card p-4">
      <p className="mb-3 text-sm font-semibold text-white">Campus Map</p>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {buildings.map((b) => (
          <button
            key={b.building}
            onClick={() => onSelect?.(b.building)}
            className={`rounded-xl border p-3 text-left transition hover:scale-[1.02] ${
              riskColor[b.risk_level] || riskColor.LOW
            } ${selected === b.building ? "ring-2 ring-cyan-400" : ""}`}
          >
            <div className="flex items-center gap-2">
              <span className={`h-2 w-2 rounded-full ${riskDot[b.risk_level] || riskDot.LOW}`} />
              <span className="text-xs font-semibold text-slate-100">{b.building}</span>
            </div>
            <p className="mt-2 text-lg font-bold text-white">{Math.round(b.health_score)}</p>
            <p className="text-[10px] uppercase tracking-wide text-slate-400">Health score</p>
          </button>
        ))}
      </div>
    </div>
  );
}
