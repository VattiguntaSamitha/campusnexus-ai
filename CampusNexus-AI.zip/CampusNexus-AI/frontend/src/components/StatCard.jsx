import React from "react";

export default function StatCard({ label, value, sublabel, accent = "cyan" }) {
  const accentClasses = {
    cyan: "text-cyan-300",
    red: "text-red-400",
    amber: "text-amber-400",
    emerald: "text-emerald-400",
  };
  return (
    <div className="card p-4">
      <p className="text-xs font-medium uppercase tracking-wide text-slate-400">{label}</p>
      <p className={`mt-1 text-3xl font-bold ${accentClasses[accent] || accentClasses.cyan}`}>{value}</p>
      {sublabel && <p className="mt-1 text-xs text-slate-500">{sublabel}</p>}
    </div>
  );
}
