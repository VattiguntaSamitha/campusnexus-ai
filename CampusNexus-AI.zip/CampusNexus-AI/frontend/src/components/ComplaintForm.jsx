import React, { useState } from "react";
import { analyzeComplaint, submitComplaint } from "../api";

export default function ComplaintForm({ onSubmitted }) {
  const [text, setText] = useState("");
  const [role, setRole] = useState("student");
  const [preview, setPreview] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handlePreview() {
    if (text.trim().length < 5) return;
    setLoading(true);
    setError("");
    try {
      const result = await analyzeComplaint(text);
      setPreview(result);
    } catch (err) {
      setError(err?.response?.data?.detail || "Could not analyze complaint. Is the backend running?");
    } finally {
      setLoading(false);
    }
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (text.trim().length < 5) return;
    setLoading(true);
    setError("");
    try {
      const saved = await submitComplaint(text, role);
      setPreview(null);
      setText("");
      onSubmitted?.(saved);
    } catch (err) {
      setError(err?.response?.data?.detail || "Could not submit complaint.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="card p-4">
      <p className="mb-3 text-sm font-semibold text-white">Submit a Complaint</p>
      <form onSubmit={handleSubmit} className="space-y-3">
        <textarea
          className="w-full rounded-lg border border-slate-700 bg-slate-900 p-3 text-sm text-slate-100 outline-none focus:border-cyan-500"
          rows={3}
          placeholder='e.g. "The AC in Block B room 304 is making strange noise and the room is very hot."'
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
        <div className="flex items-center gap-3">
          <select
            className="rounded-lg border border-slate-700 bg-slate-900 px-2 py-1.5 text-sm text-slate-200"
            value={role}
            onChange={(e) => setRole(e.target.value)}
          >
            <option value="student">Student</option>
            <option value="faculty">Faculty</option>
            <option value="maintenance">Maintenance</option>
          </select>
          <button
            type="button"
            onClick={handlePreview}
            disabled={loading}
            className="rounded-lg border border-slate-700 px-3 py-1.5 text-sm font-medium text-slate-200 hover:bg-slate-800 disabled:opacity-50"
          >
            Analyze
          </button>
          <button
            type="submit"
            disabled={loading}
            className="rounded-lg bg-cyan-500 px-3 py-1.5 text-sm font-semibold text-slate-900 hover:bg-cyan-400 disabled:opacity-50"
          >
            Submit
          </button>
        </div>
      </form>

      {error && <p className="mt-3 text-sm text-red-400">{error}</p>}

      {preview && (
        <div className="mt-4 rounded-lg border border-slate-700 bg-slate-900/60 p-3">
          <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-cyan-300">NLP Analysis</p>
          <div className="grid grid-cols-2 gap-2 text-sm sm:grid-cols-3">
            <Field label="Building" value={preview.building} />
            <Field label="Room" value={preview.room} />
            <Field label="Equipment" value={preview.equipment} />
            <Field label="Category" value={preview.category} />
            <Field label="Severity" value={preview.severity} />
            <Field label="Urgency" value={preview.urgency} />
          </div>
          <p className="mt-2 text-xs text-slate-400">{preview.problem}</p>

          {preview.similar_complaints?.length > 0 && (
            <div className="mt-3">
              <p className="mb-1 text-xs font-semibold uppercase tracking-wide text-slate-400">
                Similar historical complaints
              </p>
              <ul className="space-y-1">
                {preview.similar_complaints.slice(0, 3).map((s) => (
                  <li key={s.id} className="text-xs text-slate-400">
                    <span className="text-cyan-300">{Math.round(s.similarity * 100)}%</span> — {s.text}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function Field({ label, value }) {
  return (
    <div>
      <p className="text-[10px] uppercase tracking-wide text-slate-500">{label}</p>
      <p className="font-medium text-slate-100">{value || "—"}</p>
    </div>
  );
}
