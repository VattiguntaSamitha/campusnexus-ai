import React from "react";

const priorityBadge = {
  HIGH: "badge-HIGH",
  MEDIUM: "badge-MEDIUM",
  LOW: "badge-LOW",
};

export default function RecommendationCard({ recommendation }) {
  return (
    <div className="card flex items-start justify-between gap-3 p-4">
      <div>
        <p className="text-sm font-semibold text-white">{recommendation.building}</p>
        <p className="mt-1 text-sm text-slate-300">{recommendation.message}</p>
        <p className="mt-1 text-xs text-slate-500">{new Date(recommendation.created_at).toLocaleString()}</p>
      </div>
      <span className={`${priorityBadge[recommendation.priority] || "badge-LOW"} shrink-0 rounded-full px-2.5 py-1 text-xs font-bold`}>
        {recommendation.priority}
      </span>
    </div>
  );
}
