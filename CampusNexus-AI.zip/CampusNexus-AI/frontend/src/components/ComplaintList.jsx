import React from "react";

const severityBadge = {
  HIGH: "badge-HIGH",
  MEDIUM: "badge-MEDIUM",
  LOW: "badge-LOW",
};

export default function ComplaintList({ complaints = [] }) {
  if (complaints.length === 0) {
    return <div className="card p-4 text-sm text-slate-400">No complaints yet.</div>;
  }

  return (
    <div className="card divide-y divide-slate-800">
      {complaints.map((c) => (
        <div key={c.id} className="p-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-sm text-slate-100">{c.raw_text}</p>
              <p className="mt-1 text-xs text-slate-500">
                {c.building || "Unknown building"}
                {c.room ? ` · Room ${c.room}` : ""}
                {c.equipment ? ` · ${c.equipment}` : ""} ·{" "}
                {new Date(c.created_at).toLocaleString()}
              </p>
            </div>
            <div className="flex shrink-0 flex-col items-end gap-1">
              <span className="rounded-full bg-slate-800 px-2 py-0.5 text-[10px] font-semibold text-slate-300">
                {c.category}
              </span>
              <span className={`${severityBadge[c.severity] || "badge-LOW"} rounded-full px-2 py-0.5 text-[10px] font-bold`}>
                {c.severity}
              </span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
