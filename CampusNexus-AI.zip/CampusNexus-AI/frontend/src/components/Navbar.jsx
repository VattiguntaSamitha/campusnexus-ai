import React from "react";
import { NavLink } from "react-router-dom";

const links = [
  { to: "/", label: "Dashboard" },
  { to: "/complaints", label: "Complaints" },
  { to: "/predictions", label: "Predictions" },
  { to: "/simulator", label: "Simulator" },
  { to: "/assistant", label: "Assistant" },
];

export default function Navbar() {
  return (
    <nav className="sticky top-0 z-10 border-b border-slate-800 bg-[#0b1220]/95 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3">
        <div className="flex items-center gap-2">
          <span className="text-xl font-bold tracking-tight text-white">
            CampusNexus <span className="text-cyan-400">AI</span>
          </span>
          <span className="hidden rounded-full bg-cyan-500/10 px-2 py-0.5 text-xs font-medium text-cyan-300 sm:inline">
            Digital Twin
          </span>
        </div>
        <div className="flex gap-1 overflow-x-auto">
          {links.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.to === "/"}
              className={({ isActive }) =>
                `whitespace-nowrap rounded-lg px-3 py-1.5 text-sm font-medium transition ${
                  isActive
                    ? "bg-cyan-500/15 text-cyan-300"
                    : "text-slate-400 hover:bg-slate-800 hover:text-slate-100"
                }`
              }
            >
              {link.label}
            </NavLink>
          ))}
        </div>
      </div>
    </nav>
  );
}
